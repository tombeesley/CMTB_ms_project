function tetio_setFrameRate(rate)
	tetio_matlab('tetio_setFrameRate', rate);
end
