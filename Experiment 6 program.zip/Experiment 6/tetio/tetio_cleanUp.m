function tetio_cleanUp()
	tetio_matlab('tetio_cleanUp');
end
