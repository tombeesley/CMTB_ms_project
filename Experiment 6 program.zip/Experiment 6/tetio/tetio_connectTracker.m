function tetio_connectTracker(s)
	tetio_matlab('tetio_connectTracker', s);
end
