function time = tetio_localToRemoteTime(localTime)
	time = tetio_matlab('tetio_localToRemoteTime', localTime);
end
