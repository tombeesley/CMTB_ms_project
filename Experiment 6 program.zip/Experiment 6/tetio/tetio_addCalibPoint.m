function tetio_addCalibPoint(x, y)
tetio_matlab('tetio_addCalibPoint', x, y);
end
