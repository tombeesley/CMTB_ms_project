function [training, test1] = setTrials(b1, b2, b3)

% Training design
% Phase 1
design = [1 1 5 ; 2 2 6 ; 3 3 7 ; 4 4 8];
N = size(design,1);
training1 = zeros(N*b1,3);
for b = 1:b1
    step = (b-1)*N;
    temp = design;
    temp = temp(randperm(N),:);
    if b > 1
        while temp(1,1) == training1(step,1)
            temp = temp(randperm(N),:);
        end
    end
    training1(step+1:step+N,:) = temp;
    
end

% Phase 2
design = [5 1 9 ; 6 2 10 ; 7 3 11 ; 8 4 12];
N = size(design,1);
training2 = zeros(N*b2,3);
for b = 1:b2
    step = (b-1)*N;
    temp = design;
    temp = temp(randperm(N),:);
    if b > 1
        while temp(1,1) == training2(step,1)
            temp = temp(randperm(N),:);
        end
    end
    training2(step+1:step+N,:) = temp;
    
end

% Phase 3
design = [9 1 13 ; 10 2 14 ; 11 3 15 ; 12 4 16];
N = size(design,1);
training3 = zeros(N*b3,3);
for b = 1:b3
    step = (b-1)*N;
    temp = design;
    temp = temp(randperm(N),:);
    if b > 1
        while temp(1,1) == training3(step,1)
            temp = temp(randperm(N),:);
        end
    end
    training3(step+1:step+N,:) = temp;
    
end
training = [training1;training2;training3];

% test 2 design (original, recipient, answer)
test1 = [1:4:13 ; 2:4:14 ; 3:4:15 ; 4:4:16];
test1 = test1(randperm(4),:);
