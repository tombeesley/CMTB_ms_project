function MainProc
clc
runET = 0; % controls running of ET or not

if runET == 0
    GenericCalibration; runET = 0;
end

RandStream.setGlobalStream(RandStream('mt19937ar','seed',sum(100*clock)));

blocks = [6 6 6]; % stage 1, 2 and 3

format bank; %output data in easy to read format

subNum = input('Enter subject number ---> ');
cond = input('Enter condition ---> ');

%check if this subject and session has been run
app_home = cd;
cd(app_home); 
filename = ['C', int2str(cond) '_S', int2str(subNum)];
filePath = strcat(app_home,'\DATA\',filename);
if exist(strcat(filePath,'.mat'), 'file') > 0
    strcat(filename, ' already exists - check program parameters and try again.')
    return
end

filePath = strcat(app_home,'\DATA\',filename);
DATA = []; DATA_EG = [];
save(filePath,'DATA','DATA_EG', '-v7.3'); % save DATA structure

clc % clear screen 
disp(['C', int2str(cond), '/S', int2str(subNum)]); %diplay conditions/subnum

% write subject details
age = input('Enter your age ---> ');
sex = input('Enter your gender (m/f) ---> ', 's' );
hand = input('Are you right or left handed? (r/l) ---> ','s');
language = input('Is English your first language? (y/n) ---> ','s');
start_time = datestr(now,0);
DATA.details = {age sex hand language start_time cond};

KbName('UnifyKeyNames');    % Important for some reason to standardise keyboard input across platforms / OSs.

% screen setup
res=[1920 1080];
midx = res(1)/2;
midy = res(2)/2;

Fixation_Time = 1;
Feedback_Time = 2;

OKBtn_size = [150 60];
ContBtn_size = [140 50];
ContBtnPos = [res(1)-ContBtn_size(1)-200 res(2)-ContBtn_size(2)-50 res(1)-200 res(2)-50];
BackBtn_size = [140 50];

% Placement of Animal stimuli at the top
A_size = 150;
A_space = 350;
A_fromTop = 50; % How far from top of screen
ATopGrid = zeros(5,4);
for a = 1:4
    ATopGrid(a,1) = (a-1)*A_size + (a-1)*A_space; %left
    ATopGrid(a,3) = ATopGrid(a,1)+A_size; %right
end
ATopGrid(1:4,[1 3]) = ATopGrid(1:4,[1 3]) + (res(1) - ATopGrid(4,3))*.5; % centres complete grid horizontally
ATopGrid(5,[1 3]) = [midx-A_size/2 midx+A_size/2]; %centre
ATopGrid(:,2) = A_fromTop; % Top 
ATopGrid(:,4) = A_fromTop + A_size; % Bottom

% Placement of Animal stimuli at the bottom (Grid 1-4 and centre)
ABotGrid = zeros(5,4);
ABotGrid(1:5,:) = ATopGrid;
ABotGrid(:,2) = res(2)-A_fromTop-A_size; % Top 
ABotGrid(:,4) = res(2)-A_fromTop; %Bottom

% Placement of presents 
P_size = 150;
P_space = 350;
P_fromTop = 600; % How far from top of screen
PGrid = zeros(4,4);
for p = 1:4
    PGrid(p,1) = (p-1)*P_size + (p-1)*P_space; %left
    PGrid(p,3) = PGrid(p,1)+P_size; %right
    PGrid(p,[2 4]) = [P_fromTop P_fromTop + P_size]; % Top / Bottom
end
PGrid(:,[1 3]) = PGrid(:,[1 3]) + (res(1) - PGrid(4,3))*.5; % centres complete grid horizontally

if cond == 2 % proximal placement of animals by presents
    keepTestGrid = ATopGrid; % keeps the arrangement for use in test
    ATopGrid = PGrid; % make animals same position as presents
    ATopGrid(:,[2 4]) = ATopGrid(:,[2 4]) - 150; %offset from presents
end

% MainWindow for experiment
global MainWindow
MainWindow = Screen('OpenWindow',0,[255 255 255],[0 0 res(1) res(2)]);

% Create Animal Textures (selects animals or bags depending on the
% condition)
for i = 1:18
    if cond <= 2
        imagename = ['Stimuli\Final images\Animal', int2str(i), '.png'];
    elseif cond == 3
        imagename = ['Stimuli\Final images\Bag', int2str(i), '.jpg'];
    end
    Animal(i) = Screen('MakeTexture', MainWindow, double(imread(imagename)));
end

QM = Screen('MakeTexture', MainWindow, double(imread('Stimuli\Final images\QuestionMark.png')));

% randomisation of outcomes & cues
x = randperm(16);
Animal(1:16) = Animal(x);
DATA.Animals_Order = x;

% % Create Present Textures
if cond <=2
    Present(1) = Screen('MakeTexture', MainWindow, double(imread('Stimuli\Final images\Present1.png'))); Present_Names{1} = ' balloon';
    Present(2) = Screen('MakeTexture', MainWindow, double(imread('Stimuli\Final images\Present2.png'))); Present_Names{2} = ' cake';
    Present(3) = Screen('MakeTexture', MainWindow, double(imread('Stimuli\Final images\Present3.png'))); Present_Names{3} = ' lolly';
    Present(4) = Screen('MakeTexture', MainWindow, double(imread('Stimuli\Final images\Present4.png'))); Present_Names{4} = ' bear';
elseif cond == 3
    Present(1) = Screen('MakeTexture', MainWindow, double(imread('Stimuli\Final images\marble1.jpg'))); Present_Names{1} = ' blue marble';
    Present(2) = Screen('MakeTexture', MainWindow, double(imread('Stimuli\Final images\marble2.jpg'))); Present_Names{2} = ' green marble';
    Present(3) = Screen('MakeTexture', MainWindow, double(imread('Stimuli\Final images\marble3.jpg'))); Present_Names{3} = ' yellow marble';
    Present(4) = Screen('MakeTexture', MainWindow, double(imread('Stimuli\Final images\marble4.jpg'))); Present_Names{4} = ' black marble';
end

% randomisation of outcomes & cues
x = randperm(4);
Present = Present(x);
Present_Names = Present_Names(x);
DATA.Presents_Order = x;

% practice instruction box
PracLBLsize = [1920 60];
PracLBL = Screen('OpenOffscreenWindow', MainWindow, [255 255 255], [0 0 PracLBLsize(1) PracLBLsize(2)]);
Screen('TextSize', PracLBL, 30);
Screen('TextFont', PracLBL, 'Calibri');
Screen('TextColor',PracLBL, [0 150 0]);
if cond <= 2
    DrawFormattedText(PracLBL, 'The monkey is giving a present to someone. Click on the present you think the monkey is giving.', 'center', 'center');
elseif cond == 3
    DrawFormattedText(PracLBL, 'This bag contains a marble that we will put in another bag. Click on the marble you think will be transferred from this bag.', 'center', 'center');
end

% Create UNDO Button Texture
UNDOButton = Screen('OpenOffscreenWindow', MainWindow, [130 130 130], [0 0 OKBtn_size(1) OKBtn_size(2)]);
Screen('FrameRect', UNDOButton, [100 100 100] , [], 5);
Screen('TextSize', UNDOButton, 30);
Screen('TextFont', UNDOButton, 'Calibri');
DrawFormattedText(UNDOButton, 'UNDO', 'center', 'center', [255 255 255]);

% Instructions 
for i = 1:16 
    if cond <= 2
        Ftext = strcat('Instructions\Animals\Slide',int2str(i),'.jpg');
    elseif cond == 3
        Ftext = strcat('Instructions\Bags\Slide',int2str(i),'.jpg');
    end
    instStim(i) =Screen('MakeTexture', MainWindow, double(imread(Ftext)));
end 

% Create Continue Button Texture
ContBtn = Screen('OpenOffscreenWindow', MainWindow, [130 130 130], [0 0 ContBtn_size(1) ContBtn_size(2)]);
Screen('FrameRect', ContBtn, [100 100 100] , [], 5);
Screen('TextSize', ContBtn, 30);
Screen('TextFont', ContBtn, 'Calibri');
DrawFormattedText(ContBtn, 'Continue', 'center', 'center', [255 255 255]);

% Create Back Button Texture
BackBtn = Screen('OpenOffscreenWindow', MainWindow, [130 130 130], [0 0 BackBtn_size(1) BackBtn_size(2)]);
Screen('FrameRect', BackBtn, [100 100 100] , [], 5);
Screen('TextSize', BackBtn, 30);
Screen('TextFont', BackBtn, 'Calibri');
DrawFormattedText(BackBtn, 'Back', 'center', 'center', [255 255 255]);

%get the trial structure
[TT, TTtest1] = setTrials(blocks(1), blocks(2), blocks(3));

if runET == 1; tetio_startTracking; end
tempTS = zeros(1,5);
pracDone = false; trial = 1;

% need to change this when blocks are changed
instTrials = [1 1; 5 3; 9 4; 13 4; 17 4; 21 5; 25 6; 29 7; 33 8; 37 8; 41 8; 45 9; 49 10; 53 11; 57 12; 61 12; 65 12; 69 13];

ShowCursor('Arrow');

% START OF PROCEDURE
while trial <= size(TT,1)
    
    % Set Instructions in main task
    insRow = find(instTrials(:,1)==trial);    
    if isempty(insRow) == 0
        InstCnt = instTrials(insRow,2);
        if InstCnt == 1 && pracDone == true
            InstCnt = 2;
        end
        %Present Instructions, wait for keypress
        Screen('DrawTexture', MainWindow, instStim(InstCnt), [], []); % Instruction 1
        Screen('DrawTexture', MainWindow, ContBtn, [], ContBtnPos);
        Screen(MainWindow, 'Flip');
        stimClicked = 0;
        while stimClicked == 0
            [~, ClickX, ClickY, ~] = GetClicks(MainWindow, 0); % wait for click
            stimClicked = checkClickOnStim(ClickX,ClickY,ContBtnPos);
        end
    end
    Screen(MainWindow, 'Flip');
    WaitSecs(Fixation_Time); %blank screen
        
    % draw stimuli on screen 
    if pracDone == true
        giver = TT(trial,1);
        pres = TT(trial,2);
        recipient = TT(trial,3);
    else
        % practice settings
        giver = 17;
        pres = randi(4);
        recipient = 18;
        Screen('DrawTexture',MainWindow,PracLBL,[],[midx-PracLBLsize(1)/2 midy-200 midx+PracLBLsize(1)/2 midy-200+PracLBLsize(2)]);
    end
        
    Screen('DrawTexture', MainWindow, Animal(giver), [], ABotGrid(5,:));
    for p = 1:4 % draw presents
        Screen('DrawTexture', MainWindow, Present(p), [], PGrid(p,:)); 
    end  
    tempTS(1) = Screen(MainWindow, 'Flip',[],1); % stim On

    PChosen = 0; rNum = 0; tempRs = zeros(10,1); %temp variable to hold 10 responses.
    
    while PChosen ~= pres
        
        % wait for mouse click on a present
        [~, ClickX, ClickY, ~] = GetClicks(MainWindow, 0);
        tempTS(2) = GetSecs; % Time Stamp Button Clicked (last storage is OK Button)
        stimClicked = checkClickOnStim(ClickX,ClickY,PGrid);
        
        % look up what to do on basis of object clicked
        if stimClicked > 0
            
            PChosen = stimClicked;
            if PChosen == pres
                % correct present
                Screen('DrawTexture', MainWindow, Animal(recipient), [], ATopGrid(pres,:));
                Screen(MainWindow, 'Flip',[],1);
                PlaySound(1,'Stimuli\correct2.wav');                
            else
                % incorrect present
                PlaySound(1,'Stimuli\incorrect2.wav');
            end
            rNum = rNum + 1;
            if rNum <= size(tempRs,1)
                tempRs(rNum) = PChosen;
            end
        end    
    end
    imwrite(Screen('GetImage', MainWindow), 'ssFeedback.jpg');
    WaitSecs(Feedback_Time);
    Screen(MainWindow, 'Flip'); % Screen off
    tempTS(3) = GetSecs; % Time Stamp Feedback off
  
    if pracDone == true % only record data after practice trial
    
        if runET == 1
            [lefteye, righteye, timestamp, ~] = tetio_readGazeData;
            DATA_EG.DEC(trial,:) = parseEyeData(timestamp, lefteye, righteye, tempTS(1), tempTS(2));
            DATA_EG.FB(trial,:) = parseEyeData(timestamp, lefteye, righteye, tempTS(2), tempTS(3));
        end

        %write trial data to the file
        DATA.training_data(trial,1:6) = [trial TT(trial,:) rNum (tempTS(2) - tempTS(1))*1000];
        DATA.responses(trial,1:size(tempRs)) = tempRs;
        save(filePath,'DATA'); % save DATA structure
    
    end
    
    trial = trial + 1;
    if pracDone == false % practice trial over
        pracDone = true;
        trial = 1;
    end
end

if runET == 1; tetio_stopTracking; end

% TEST 1
if cond == 2
    ATopGrid = keepTestGrid;
end
ATopGrid = ATopGrid + 50; %moves them down a bit

Screen('DrawTexture', MainWindow, instStim(14), [], []); % Instructions
Screen('DrawTexture', MainWindow, ContBtn, [], ContBtnPos);
Screen(MainWindow, 'Flip');
stimClicked = 0;
while stimClicked == 0
    [~, ClickX, ClickY, ~] = GetClicks(MainWindow, 0); % wait for click
    stimClicked = checkClickOnStim(ClickX,ClickY,ContBtnPos);
end

% the picking grid for Test 1
sizeG = 150;
spaceGx = 20;
APickGrid = zeros(16,4);
for a = 1:4
    APickGrid(a,1) = (a-1)*sizeG + (a-1)*spaceGx; %left
    APickGrid(a,3) = APickGrid(a,1)+sizeG; %right
end
APickGrid(5:16,:) = repmat(APickGrid(1:4,:),3,1);
APickGrid(:,[1 3]) = APickGrid(:,[1 3]) + (res(1) - APickGrid(4,3))*.5; % centres complete grid horizontally

APickGrid(1:4,[2 4]) = repmat([res(2)-sizeG*4 res(2)-sizeG*3],4,1);
APickGrid(5:8,[2 4]) = repmat([res(2)-sizeG*3 res(2)-sizeG*2],4,1);
APickGrid(9:12,[2 4]) = repmat([res(2)-sizeG*2 res(2)-sizeG*1],4,1);
APickGrid(13:16,[2 4]) = repmat([res(2)-sizeG*1 res(2)],4,1);
APickGrid = round(APickGrid);

% test 1 arrow texture, size and positions
Arrow = Screen('MakeTexture', MainWindow, double(imread('Stimuli\Final images\arrow.png')));
arrSize = [75 50];
arrPos = zeros(3,4);
arrPos(1,:) = [ATopGrid(1,3)+A_space/2-arrSize(1)/2 ATopGrid(1,2)+A_size/2-arrSize(2)/2 ATopGrid(1,3)+A_space/2+arrSize(1)/2 ATopGrid(1,2)+A_size/2+arrSize(2)/2];
arrPos(2,[1 3]) = [ATopGrid(2,3)+A_space/2-arrSize(1)/2 ATopGrid(2,3)+A_space/2+arrSize(1)/2];
arrPos(3,[1 3]) = [ATopGrid(3,3)+A_space/2-arrSize(1)/2 ATopGrid(3,3)+A_space/2+arrSize(1)/2];
arrPos(2,[2 4]) = arrPos(1,[2 4]); arrPos(3,[2 4]) = arrPos(1,[2 4]); % duplicate y positions for arrows

% test 1 present size and positions
presSize = [100 100];
presPos = zeros(3,4);
presPos(1,:) = [ATopGrid(1,3)+A_space/2-presSize(1)/2 arrPos(1,2)-presSize(2)-10 ATopGrid(1,3)+A_space/2+presSize(1)/2 arrPos(1,2)-10];
presPos(2,[1 3]) = [ATopGrid(2,3)+A_space/2-presSize(1)/2 ATopGrid(2,3)+A_space/2+presSize(1)/2];
presPos(3,[1 3]) = [ATopGrid(3,3)+A_space/2-presSize(1)/2 ATopGrid(3,3)+A_space/2+presSize(1)/2];
presPos(2,[2 4]) = presPos(1,[2 4]); presPos(3,[2 4]) = presPos(1,[2 4]); % duplicate y positions for arrows

bs = [150 60]; % UNDO and Cont button sizes for Test 1
UNDOBtnPos = [res(1)-bs(1)-100 midy+120 res(1)-100 midy+120+bs(2)];
ContBtnTestPos = [res(1)-bs(1)-100 midy+200 res(1)-100 midy+200+bs(2)];

gridOrder = randperm(16); % random arrangement of animals to the grid, fixed across trials

for trial = 1:size(TTtest1,1)
    
    Screen(MainWindow, 'Flip');
    WaitSecs(Fixation_Time); %blank screen 
    finishedTrial = false;
    
    while finishedTrial == false
 
        % draw stimuli on screen 
        for a = 1:4
            Screen('DrawTexture', MainWindow, QM, [], ATopGrid(a,:)); % qusetion mark
        end
        for a = 1:3
            Screen('DrawTexture', MainWindow, Arrow, [], arrPos(a,:)); % arrows
            Screen('DrawTexture', MainWindow, Present(TTtest1(trial,1)), [], presPos(a,:)); % arrows
        end
        for a = 1:16
            Screen('DrawTexture', MainWindow, Animal(gridOrder(a)), [], APickGrid(a,:)); % grid of animals
        end  
        
        Screen('TextSize', MainWindow, 30);
        Screen('TextFont', MainWindow, 'Calibri');
        if cond <= 2
            DrawFormattedText(MainWindow, 'Select the animals in the order they', 100, midy, [0 0 0]);
        elseif cond == 3
            DrawFormattedText(MainWindow, 'Select the bags in the order they', 100, midy, [0 0 0]);
        end
        DrawFormattedText(MainWindow, cell2mat(strcat('received the ', Present_Names(TTtest1(trial,1)))), 100, midy+30, [0 0 0]);

        tempTS(1) = Screen(MainWindow, 'Flip',[],1); % stim On   

        numChosen = 0; % 
        AChosen = zeros(1,4); % record of which animals are picked.
        while numChosen <= 4 % until all 4 animals picked
            
            % wait for mouse click on a present
            [~, ClickX, ClickY, ~] = GetClicks(MainWindow, 0);
            tempTS(2) = GetSecs; % Time Stamp Button Clicked (last storage is OK Button)
            if numChosen == 0
                newChoice = checkClickOnStim(ClickX,ClickY,APickGrid);
            elseif numChosen < 4
                newChoice = checkClickOnStim(ClickX,ClickY,[APickGrid; UNDOBtnPos]);
            elseif numChosen == 4
                newChoice = checkClickOnStim(ClickX,ClickY,[APickGrid; UNDOBtnPos; ContBtnTestPos]);
            end

            % look up what to do on basis of object clicked
            if newChoice == 17 % clicked UNDOBtn
                numChosen = 5; % restart trial
                AChosen = zeros(1,4); % reset animals picked.
                Screen(MainWindow, 'Flip'); % flush the back window
            elseif newChoice == 18 && numChosen == 4 % clicked ContBtn
                numChosen = 5; % break out of loop
                finishedTrial = true; % trial finished, go to next trial
            elseif (newChoice > 0 && sum(AChosen==gridOrder(newChoice))>0) || (numChosen == 4 && newChoice < 17) % picked an existing pick
                PlaySound(1,'Stimuli\incorrect2.wav');
            elseif newChoice > 0  &&  newChoice < 17 && numChosen < 4 && sum(AChosen==gridOrder(newChoice))==0  % valid pick
                numChosen = numChosen + 1;
                AChosen(numChosen) = gridOrder(newChoice); % add to choices
                Screen('DrawTexture', MainWindow, Animal(AChosen(numChosen)), [], ATopGrid(numChosen,:)); % draw animal
                Screen('FrameRect', MainWindow , [0 0 0] , APickGrid(newChoice,:), 5); % frame the chosen animal in the grid
                Screen('DrawTexture', MainWindow, UNDOButton, [], UNDOBtnPos); % add the Undo button
                if numChosen == 4
                    Screen('DrawTexture', MainWindow, ContBtn, [], ContBtnTestPos); % add the Cont button if last pick
                end
                Screen(MainWindow, 'Flip',[],1);
            end    
        end
        
    end
    imwrite(Screen('GetImage', MainWindow), 'ssTest2.jpg');
    tempTS(2) = Screen(MainWindow, 'Flip'); % Stimuli off
    
    corResp = AChosen==TTtest1(trial,:);
    %write trial data to the file
    DATA.test1_data(trial,:) = [TTtest1(trial,:) AChosen corResp sum(corResp) (tempTS(2) - tempTS(1))*1000];
    save(filePath,'DATA'); % save DATA structure
end


% TEST 2
Screen('DrawTexture', MainWindow, instStim(15), [], []); % Instructions
Screen('DrawTexture', MainWindow, ContBtn, [], ContBtnPos);
Screen(MainWindow, 'Flip');
stimClicked = 0;
while stimClicked == 0
    [~, ClickX, ClickY, ~] = GetClicks(MainWindow, 0); % wait for click
    stimClicked = checkClickOnStim(ClickX,ClickY,ContBtnPos);
end

% the answer grid for Test 2
sizeAns = 175;
spaceAnsX = 200;
spaceAnsY = 10;
AnsGrid = zeros(16,4);
for a = 1:4
    AnsGrid(a,1) = (a-1)*sizeAns + (a-1)*spaceAnsX; %left
    AnsGrid(a,3) = AnsGrid(a,1)+sizeAns; %right
end
AnsGrid(5:16,:) = repmat(AnsGrid(1:4,:),3,1);
AnsGrid(:,[1 3]) = AnsGrid(:,[1 3]) + (res(1) - AnsGrid(4,3))*.5; % centres complete grid horizontally

AnsGrid(1:4,[2 4]) = repmat([spaceAnsY sizeAns+spaceAnsY],4,1);
AnsGrid(5:8,[2 4]) = repmat([spaceAnsY*2+sizeAns spaceAnsY*2+sizeAns*2],4,1);
AnsGrid(9:12,[2 4]) = repmat([spaceAnsY*3+sizeAns*2 spaceAnsY*3+sizeAns*3],4,1);
AnsGrid(13:16,[2 4]) = repmat([spaceAnsY*4+sizeAns*3 spaceAnsY*4+sizeAns*4],4,1);
AnsGrid(:,[2 4]) = AnsGrid(:,[2 4]) + 100; % spaces the grid from the top.
AnsGrid = round(AnsGrid);

% test 2 arrow texture, size and positions
Arrow = Screen('MakeTexture', MainWindow, double(imread('Stimuli\Final images\arrow.png')));
arrSize = [100 50];
arrPos = zeros(12,4);
for a = 1:3
    arrPos(a,1) = AnsGrid(a,3)+spaceAnsX/2-arrSize(1)/2;
    arrPos(a,3) = arrPos(a,1) + arrSize(1);
end
arrPos(4:12,:) = repmat(arrPos(1:3,:),3,1);
arrPos(1:3,[2 4]) = repmat([AnsGrid(1,2)+sizeAns*.7-arrSize(2)/2 AnsGrid(1,2)+sizeAns*.7+arrSize(2)/2],3,1);
arrPos(4:6,[2 4]) = repmat([AnsGrid(5,2)+sizeAns*.7-arrSize(2)/2 AnsGrid(5,2)+sizeAns*.7+arrSize(2)/2],3,1);
arrPos(7:9,[2 4]) = repmat([AnsGrid(9,2)+sizeAns*.7-arrSize(2)/2 AnsGrid(9,2)+sizeAns*.7+arrSize(2)/2],3,1);
arrPos(10:12,[2 4]) = repmat([AnsGrid(13,2)+sizeAns*.7-arrSize(2)/2 AnsGrid(13,2)+sizeAns*.7+arrSize(2)/2],3,1);

% test 2 present size and positions
presSize = [80 80];
presPos = zeros(12,4);
for p = 1:4
    presPos(p,[1 3]) = [AnsGrid(p,3)+spaceAnsX/2-presSize(1)/2 AnsGrid(p,3)+spaceAnsX/2+presSize(1)/2];
end
presPos(:,:) = repmat(presPos(1:3,:),4,1); % duplicates X positions
for p = 1:3:12
    presPos(p:p+2,[2 4]) = repmat([arrPos(p,2)-presSize(2)-10 arrPos(p,2)-10],3,1);
end

% Placement of Animal stimuli at the bottom (Grid 1-4 and centre)
sizeBot = 150;
spaceBotX = 150; spaceBotY = 50;
BotGrid = zeros(4,4);
for a = 1:4
    BotGrid(a,1) = (a-1)*sizeBot + (a-1)*spaceBotX; %left
    BotGrid(a,3) = BotGrid(a,1)+sizeBot; %right
end
BotGrid(:,[1 3]) = BotGrid(:,[1 3]) + (res(1) - BotGrid(4,3))*.5; % centres complete grid horizontally
BotGrid(:,[2 4]) = repmat([res(2)-sizeBot-spaceBotY res(2)-spaceBotY],4,1);

bs = [150 60]; % UNDO and Cont button sizes for Test 2
UNDOBtnPos = [res(1)-bs(1)-100 midy+120 res(1)-100 midy+120+bs(2)];
ContBtnTestPos = [res(1)-bs(1)-100 midy+200 res(1)-100 midy+200+bs(2)];

 
Screen(MainWindow, 'Flip');
    
for trial = 1:4
    
    
    WaitSecs(Fixation_Time); % pause between trials
    
    activeSet = [1:4:13 ; 2:4:14 ; 3:4:15 ; 4:4:16];
    actAnimalsCor = (1:4)+4*(trial-1); % correct sequence of animals
    actAnimals = actAnimalsCor(randperm(4)); % randomise along the bottom
    finishedTrial = false;
    while finishedTrial == false
 
        % draw stimuli on screen 
        for a = activeSet(trial,:) 
            Screen('DrawTexture', MainWindow, QM, [], AnsGrid(a,:)); % question mark
        end
            
        if trial < 4
            Pcnt = 0;
            for a = 0+trial:3:9+trial
                Screen('DrawTexture', MainWindow, Arrow, [], arrPos(a,:)); % arrows
                Pcnt = Pcnt + 1; % goes through presents
                Screen('DrawTexture', MainWindow, Present(Pcnt), [], presPos(a,:)); % presents
            end
        end
        Screen('FillRect', MainWindow , [255 255 255] , [midx-600 res(2)-200 midx+600 res(2)-50]); % blank out the feedback message
        for a = 1:4
            Screen('DrawTexture', MainWindow, Animal(actAnimals(a)), [], BotGrid(a,:)); % animals
        end

        tempTS(1) = Screen(MainWindow, 'Flip',[],1); % stim On   
        
        numChosen = 0;
        AChosen = zeros(1,4); % record of which animals are picked.
        while numChosen <= 4 % until all 4 animals picked

            % wait for mouse click on a present
            [~, ClickX, ClickY, ~] = GetClicks(MainWindow, 0);
            tempTS(2) = GetSecs; % Time Stamp Button Clicked (last storage is OK Button)
            newChoice = checkClickOnStim(ClickX,ClickY,[BotGrid; UNDOBtnPos; ContBtnTestPos]);
            % look up what to do on basis of object clicked
            if newChoice == 5 && numChosen > 0 % clicked UNDOBtn
                numChosen = 5; % restart trial
                AChosen = zeros(1,4); % reset animals picked.
            elseif newChoice == 6 && numChosen == 4 % clicked ContBtn
                numChosen = 5; % break out of loop
                finishedTrial = true; % trial finished, go to next trial
            elseif (newChoice > 0 && sum(AChosen==newChoice)>0) || (numChosen == 4 && newChoice < 5) % picked an existing pick
                PlaySound(1,'Stimuli\incorrect2.wav');
            elseif newChoice > 0  &&  newChoice < 5 && sum(AChosen==newChoice)==0 && numChosen < 4 % valid pick
                numChosen = numChosen + 1;
                AChosen(numChosen) = newChoice; % add to choices
                Screen('DrawTexture', MainWindow, Animal(actAnimals(newChoice)), [], AnsGrid(activeSet(trial,numChosen),:)); % draw animal
                Screen('FrameRect', MainWindow , [0 0 0] , BotGrid(AChosen(numChosen),:), 5); % frame the chosen animal in the grid
                Screen('DrawTexture', MainWindow, UNDOButton, [], UNDOBtnPos); % add the Undo button
                if numChosen == 4
                    Screen('DrawTexture', MainWindow, ContBtn, [], ContBtnTestPos); % add the Cont button if last pick
                end
                Screen(MainWindow, 'Flip',[],1);
            end    
        end
        
        if newChoice == 6 % continue button pressed - show correct answers
            
            numCor = sum(actAnimals(AChosen)==actAnimalsCor);           
            
            Screen('FillRect', MainWindow , [255 255 255] , [midx-600 res(2)-200 midx+600 res(2)-50]); % frame the chosen animal in the grid
            Screen('TextSize', MainWindow, 30);
            Screen('TextFont', MainWindow, 'Calibri');
            DrawFormattedText(MainWindow, ['You got ', int2str(numCor), ' correct. The correct answers will now be set.'], midx-450, res(2)-150, [0 0 0]);
            tempTS(2) = Screen(MainWindow, 'Flip', [], 1);
            WaitSecs(1);

            for a = 1:4
                Screen('DrawTexture', MainWindow, Animal(actAnimalsCor(a)), [], AnsGrid(activeSet(trial,a),:)); % correct answers
            end

            WaitSecs(1);

        end
        
    end
    
    DATA.test2_data(trial,:) = [trial actAnimals(AChosen) actAnimalsCor numCor (tempTS(2) - tempTS(1))*1000];
    save(filePath,'DATA'); % save DATA structure
    
end

% break screen prior to questionnaires
Screen('TextSize', MainWindow, 30);
Screen('TextFont', MainWindow, 'Calibri');
str1 = 'Please contact the experimenter';
Screen(MainWindow, 'Flip');
DrawFormattedText(MainWindow, str1, 'center', 'center', [0 0 0]);
Screen(MainWindow, 'Flip');
RestrictKeysForKbCheck(121); % F10
[~,~,~] = accKbWait;
DATA.Qdata = RunQuestionnaires;
save(filePath,'DATA'); % save DATA structure

% Final thank you message!
Screen('DrawTexture', MainWindow, instStim(16), [], []); % Instruction 1
Screen(MainWindow, 'Flip');
RestrictKeysForKbCheck(122); % F11
[~,~,~] = accKbWait;

% saving EG data screen
str1 = 'Saving eye tracking data, please wait...';
DrawFormattedText(MainWindow, str1, 'center', 'center', [255 255 255]);
Screen(MainWindow, 'Flip');

if runET == 1
    save(filePath,'DATA_EG','-append'); % save DATA structure
end

% Screen('Preference', 'SkipSyncTests',0);      % Restores Psychtoolbox calibrations
Screen('CloseAll');      % Releases all onscreen and offscreen windows from memory
ShowCursor

end

function detected = checkClickOnStim(x,y,stimArray)

% takes the x and y coordinate and checks if it is in one of several areas
% of interest
% stimArray contains all AOI where each row is a new AOI and the columns
% represent: [left, top, right, bottom]

detected = 0; % default is no AOI detected
for s = 1:size(stimArray,1) %for all AOIs
    checks = [x>stimArray(s,1) y>stimArray(s,2) x<stimArray(s,3) y<stimArray(s,4)]; %this checks the LTRB dimensions of the shape.
    if sum(checks)==4 % if all those are "ones"
        detected = s; % that AOI is clicked
        return % break out of loop, since it wont be in any other AOI
    end
end
        
end

function outData = parseEyeData(TS, left, right, First, Last)

f = tetio_localToRemoteTime(int64(First*10^6));
l = tetio_localToRemoteTime(int64(Last*10^6));

vr = (TS>f)&(TS<l); % valid rows

RawEG =  {[left(vr,:) right(vr,:)] TS(vr)};

outData = RawEG;

end
