

//////////////////////////////////////////////////////
///////////START TRIAL CONSTRUTION PROCEDURE/////////
/////////////////////////////////////////////////////

// Construct per-participant stimulus values

// out_x_loc for tick: [50,260,480,695]

function generate_trial_sequence(cue_images,all_stim,out_color, out_x_loc = [50,260,480,695], phase, CB, n_repeats,
out_x_ind = [0,1,2,3], out_y = 75){


// Valid combinations of stim for the experiment (from R code) 
if (CB === 'O'){
// outcome pred
var stim_comb = [{"n1":0,"or1":0,"c1":0,"n2":5,"or2":1,"c2":1,"n3":10,"or3":2,"c3":2,"n4":15,"or4":3,"c4":3},{"n1":0,"or1":0,"c1":0,"n2":5,"or2":1,"c2":1,"n3":11,"or3":2,"c3":3,"n4":14,"or4":3,"c4":2},{"n1":0,"or1":0,"c1":0,"n2":6,"or2":1,"c2":2,"n3":9,"or3":2,"c3":1,"n4":15,"or4":3,"c4":3},{"n1":0,"or1":0,"c1":0,"n2":6,"or2":1,"c2":2,"n3":11,"or3":2,"c3":3,"n4":13,"or4":3,"c4":1},{"n1":0,"or1":0,"c1":0,"n2":7,"or2":1,"c2":3,"n3":9,"or3":2,"c3":1,"n4":14,"or4":3,"c4":2},{"n1":0,"or1":0,"c1":0,"n2":7,"or2":1,"c2":3,"n3":10,"or3":2,"c3":2,"n4":13,"or4":3,"c4":1},{"n1":1,"or1":0,"c1":1,"n2":4,"or2":1,"c2":0,"n3":10,"or3":2,"c3":2,"n4":15,"or4":3,"c4":3},{"n1":1,"or1":0,"c1":1,"n2":4,"or2":1,"c2":0,"n3":11,"or3":2,"c3":3,"n4":14,"or4":3,"c4":2},{"n1":1,"or1":0,"c1":1,"n2":6,"or2":1,"c2":2,"n3":8,"or3":2,"c3":0,"n4":15,"or4":3,"c4":3},{"n1":1,"or1":0,"c1":1,"n2":6,"or2":1,"c2":2,"n3":11,"or3":2,"c3":3,"n4":12,"or4":3,"c4":0},{"n1":1,"or1":0,"c1":1,"n2":7,"or2":1,"c2":3,"n3":8,"or3":2,"c3":0,"n4":14,"or4":3,"c4":2},{"n1":1,"or1":0,"c1":1,"n2":7,"or2":1,"c2":3,"n3":10,"or3":2,"c3":2,"n4":12,"or4":3,"c4":0},{"n1":2,"or1":0,"c1":2,"n2":4,"or2":1,"c2":0,"n3":9,"or3":2,"c3":1,"n4":15,"or4":3,"c4":3},{"n1":2,"or1":0,"c1":2,"n2":4,"or2":1,"c2":0,"n3":11,"or3":2,"c3":3,"n4":13,"or4":3,"c4":1},{"n1":2,"or1":0,"c1":2,"n2":5,"or2":1,"c2":1,"n3":8,"or3":2,"c3":0,"n4":15,"or4":3,"c4":3},{"n1":2,"or1":0,"c1":2,"n2":5,"or2":1,"c2":1,"n3":11,"or3":2,"c3":3,"n4":12,"or4":3,"c4":0},{"n1":2,"or1":0,"c1":2,"n2":7,"or2":1,"c2":3,"n3":8,"or3":2,"c3":0,"n4":13,"or4":3,"c4":1},{"n1":2,"or1":0,"c1":2,"n2":7,"or2":1,"c2":3,"n3":9,"or3":2,"c3":1,"n4":12,"or4":3,"c4":0},{"n1":3,"or1":0,"c1":3,"n2":4,"or2":1,"c2":0,"n3":9,"or3":2,"c3":1,"n4":14,"or4":3,"c4":2},{"n1":3,"or1":0,"c1":3,"n2":4,"or2":1,"c2":0,"n3":10,"or3":2,"c3":2,"n4":13,"or4":3,"c4":1},{"n1":3,"or1":0,"c1":3,"n2":5,"or2":1,"c2":1,"n3":8,"or3":2,"c3":0,"n4":14,"or4":3,"c4":2},{"n1":3,"or1":0,"c1":3,"n2":5,"or2":1,"c2":1,"n3":10,"or3":2,"c3":2,"n4":12,"or4":3,"c4":0},{"n1":3,"or1":0,"c1":3,"n2":6,"or2":1,"c2":2,"n3":8,"or3":2,"c3":0,"n4":13,"or4":3,"c4":1},{"n1":3,"or1":0,"c1":3,"n2":6,"or2":1,"c2":2,"n3":9,"or3":2,"c3":1,"n4":12,"or4":3,"c4":0}];
}else{
// color pred 
var stim_comb = [{"n1":0,"or1":0,"c1":0,"n2":5,"or2":1,"c2":1,"n3":10,"or3":2,"c3":2,"n4":15,"or4":3,"c4":3},{"n1":0,"or1":0,"c1":0,"n2":5,"or2":1,"c2":1,"n3":14,"or3":3,"c3":2,"n4":11,"or4":2,"c4":3},{"n1":0,"or1":0,"c1":0,"n2":9,"or2":2,"c2":1,"n3":6,"or3":1,"c3":2,"n4":15,"or4":3,"c4":3},{"n1":0,"or1":0,"c1":0,"n2":9,"or2":2,"c2":1,"n3":14,"or3":3,"c3":2,"n4":7,"or4":1,"c4":3},{"n1":0,"or1":0,"c1":0,"n2":13,"or2":3,"c2":1,"n3":6,"or3":1,"c3":2,"n4":11,"or4":2,"c4":3},{"n1":0,"or1":0,"c1":0,"n2":13,"or2":3,"c2":1,"n3":10,"or3":2,"c3":2,"n4":7,"or4":1,"c4":3},{"n1":4,"or1":1,"c1":0,"n2":1,"or2":0,"c2":1,"n3":10,"or3":2,"c3":2,"n4":15,"or4":3,"c4":3},{"n1":4,"or1":1,"c1":0,"n2":1,"or2":0,"c2":1,"n3":14,"or3":3,"c3":2,"n4":11,"or4":2,"c4":3},{"n1":4,"or1":1,"c1":0,"n2":9,"or2":2,"c2":1,"n3":2,"or3":0,"c3":2,"n4":15,"or4":3,"c4":3},{"n1":4,"or1":1,"c1":0,"n2":9,"or2":2,"c2":1,"n3":14,"or3":3,"c3":2,"n4":3,"or4":0,"c4":3},{"n1":4,"or1":1,"c1":0,"n2":13,"or2":3,"c2":1,"n3":2,"or3":0,"c3":2,"n4":11,"or4":2,"c4":3},{"n1":4,"or1":1,"c1":0,"n2":13,"or2":3,"c2":1,"n3":10,"or3":2,"c3":2,"n4":3,"or4":0,"c4":3},{"n1":8,"or1":2,"c1":0,"n2":1,"or2":0,"c2":1,"n3":6,"or3":1,"c3":2,"n4":15,"or4":3,"c4":3},{"n1":8,"or1":2,"c1":0,"n2":1,"or2":0,"c2":1,"n3":14,"or3":3,"c3":2,"n4":7,"or4":1,"c4":3},{"n1":8,"or1":2,"c1":0,"n2":5,"or2":1,"c2":1,"n3":2,"or3":0,"c3":2,"n4":15,"or4":3,"c4":3},{"n1":8,"or1":2,"c1":0,"n2":5,"or2":1,"c2":1,"n3":14,"or3":3,"c3":2,"n4":3,"or4":0,"c4":3},{"n1":8,"or1":2,"c1":0,"n2":13,"or2":3,"c2":1,"n3":2,"or3":0,"c3":2,"n4":7,"or4":1,"c4":3},{"n1":8,"or1":2,"c1":0,"n2":13,"or2":3,"c2":1,"n3":6,"or3":1,"c3":2,"n4":3,"or4":0,"c4":3},{"n1":12,"or1":3,"c1":0,"n2":1,"or2":0,"c2":1,"n3":6,"or3":1,"c3":2,"n4":11,"or4":2,"c4":3},{"n1":12,"or1":3,"c1":0,"n2":1,"or2":0,"c2":1,"n3":10,"or3":2,"c3":2,"n4":7,"or4":1,"c4":3},{"n1":12,"or1":3,"c1":0,"n2":5,"or2":1,"c2":1,"n3":2,"or3":0,"c3":2,"n4":11,"or4":2,"c4":3},{"n1":12,"or1":3,"c1":0,"n2":5,"or2":1,"c2":1,"n3":10,"or3":2,"c3":2,"n4":3,"or4":0,"c4":3},{"n1":12,"or1":3,"c1":0,"n2":9,"or2":2,"c2":1,"n3":2,"or3":0,"c3":2,"n4":7,"or4":1,"c4":3},{"n1":12,"or1":3,"c1":0,"n2":9,"or2":2,"c2":1,"n3":6,"or3":1,"c3":2,"n4":3,"or4":0,"c4":3}];
};


	
// cue array is already shuffled in index


// sample a valid combination of stim for experiment
var stim_ind = jsPsych.randomization.sampleWithReplacement(stim_comb,4*n_repeats)


// stim stores image location of selected row of stim, orientation value of stim and cue associated with stim 
var stim = [{name: all_stim[stim_ind[0].n1], or: stim_ind[0].or1, color: stim_ind[0].c1, cue: cue_images[0]}, 
			{name: all_stim[stim_ind[0].n2], or: stim_ind[0].or2, color: stim_ind[0].c2, cue: cue_images[1]},
			{name: all_stim[stim_ind[0].n3], or: stim_ind[0].or3, color: stim_ind[0].c3, cue: cue_images[2]},
			{name: all_stim[stim_ind[0].n4], or: stim_ind[0].or4, color: stim_ind[0].c4, cue: cue_images[3]}];

// shuffle stim and outcome together
var loc_shuffle = jsPsych.randomization.shuffleNoRepeats([0,1,2,3]);
var stim = [[stim[loc_shuffle[0]], stim[loc_shuffle[1]], stim[loc_shuffle[2]], stim[loc_shuffle[3]]]];


for(var i = 1; i < 4 * n_repeats ; i++){
	var loc_shuffle = jsPsych.randomization.shuffleNoRepeats([0,1,2,3]);
	
	var next_stim = [{name: all_stim[stim_ind[i].n1], or: stim_ind[i].or1, color: stim_ind[i].c1, cue: cue_images[0]}, 
			{name: all_stim[stim_ind[i].n2], or: stim_ind[i].or2, color: stim_ind[i].c2, cue: cue_images[1]},
			{name: all_stim[stim_ind[i].n3], or: stim_ind[i].or3, color: stim_ind[i].c3, cue: cue_images[2]},
			{name: all_stim[stim_ind[i].n4], or: stim_ind[i].or4, color: stim_ind[i].c4, cue: cue_images[3]}];
	
	stim.push([next_stim[loc_shuffle[0]], next_stim[loc_shuffle[1]], next_stim[loc_shuffle[2]], next_stim[loc_shuffle[3]]]);
};

// slice out_cue at first trial to line up colour cue for next trial
var out_cue = stim.slice(1); 

// push a new row to out_cue so n rows is correct
var last_ind = jsPsych.randomization.sampleWithoutReplacement(stim_comb,1)

out_cue.push([{name: all_stim[last_ind[0].n1], or: last_ind[0].or1, color: last_ind[0].c1, cue: cue_images[0]}, 
			{name: all_stim[last_ind[0].n2], or: last_ind[0].or2, color: last_ind[0].c2, cue: cue_images[1]},
			{name: all_stim[last_ind[0].n3], or: last_ind[0].or3, color: last_ind[0].c3, cue: cue_images[2]},
			{name: all_stim[last_ind[0].n4], or: last_ind[0].or4, color: last_ind[0].c4, cue: cue_images[3]}]);





// generate order of correct responses (x locations), using no repeat to stop consecutive trials having the same answer 
// number in repeat determines length of experiment 
var out_x_seq = jsPsych.randomization.shuffleNoRepeats(jsPsych.randomization.repeat(out_x_ind,n_repeats)); // sequence of correct feebdack


// use correct answers to construct order of outcome cues 
// get last trial value 
var out_cue_seq = out_x_seq.slice(1); // slice out x array to drop first value; sequence of outcome colors

var last_outcome = out_cue_seq[out_cue_seq.length-1]; // get last outcome so it isn't repeated 

var copy_out_x_ind = out_x_ind.slice()

var drop_x_index = copy_out_x_ind.indexOf(last_outcome); // get index of last value for dropping

copy_out_x_ind.splice(drop_x_index, 1); // drop value of first outcome location from out_x_loc


var last_trial_samp = jsPsych.randomization.sampleWithoutReplacement(copy_out_x_ind,1)[0]


// add new last trial to outcome
out_cue_seq.push(last_trial_samp); 


// build trial sequence from params sampled above

// cue determined by out_x_seq
// outcome slot determined by out_x_seq
// stim loc determined by stim_mat (how related to sequence variables???)
// out_cue color determined by out_cue_seq 
// out_cue color needs to be related to slots 

// trial 0


//var trial_stimuli = [{cue: stim[0][out_x_seq[0]].cue, correct: stim[0][out_x_seq[0]].name, stim1: stim[0][0].name, stim2: stim[0][1].name , stim3: stim[0][2].name, stim4: stim[0][3].name, out_cue: out_cue[0][out_cue_seq[0]].c,out_x: out_x_loc[out_x_seq[0]],out_y: out_y , trial: 0}];

////////////////////////////////////////////////////////////////////////////////
/// CONTROL PATH FOR COUNTERBALANCING COLOR AND ORIENTATION PREDICTIVE VALUE ///
////////////////////////////////////////////////////////////////////////////////

if (CB === 'O'){ // If orientation is predictive

	var correct_name = stim[0].find(el => el.or === out_x_seq[0]).name

	if(correct_name === stim[0][0].name){ var feedback1_name = correct_name}else{ var feedback1_name = "images/blank.png"}
	if(correct_name === stim[0][1].name){ var feedback2_name = correct_name}else{ var feedback2_name = "images/blank.png"} 
	if(correct_name === stim[0][2].name){ var feedback3_name = correct_name}else{ var feedback3_name = "images/blank.png"}
	if(correct_name === stim[0][3].name){ var feedback4_name = correct_name}else{ var feedback4_name = "images/blank.png"}

	var trial_stimuli = [{
		cue: stim[0].find(el => el.or === out_x_seq[0]).cue, 
		correct: correct_name, 
		correct_col: stim[0].find(el => el.or === out_x_seq[0]).color,
		correct_or: stim[0].find(el => el.or === out_x_seq[0]).or,
		stim1: stim[0][0].name, 
		stim2: stim[0][1].name , 
		stim3: stim[0][2].name, 
		stim4: stim[0][3].name,
		out_cue: out_color[out_cue[0].find(el => el.or === out_cue_seq[0]).color].c, 
		out_image: out_color[out_cue[0].find(el => el.or === out_cue_seq[0]).color].out_c_image, 
		out_x: out_x_loc[stim[0].findIndex(el => el.or === out_x_seq[0])],
		out_y: out_y, 
		feedback1: feedback1_name,
		feedback2: feedback2_name, 
		feedback3: feedback3_name, 
		feedback4: feedback4_name, 
		trial: 0, 
		phase: phase
	}];


	for(var i = trial_stimuli[0].trial + 1; i < out_x_seq.length; i++){
		
		var correct_name = stim[i].find(el => el.or === out_x_seq[i]).name

		if(correct_name === stim[i][0].name){ var feedback1_name = correct_name}else{ var feedback1_name = "images/blank.png"}
		if(correct_name === stim[i][1].name){ var feedback2_name = correct_name}else{ var feedback2_name = "images/blank.png"} 
		if(correct_name === stim[i][2].name){ var feedback3_name = correct_name}else{ var feedback3_name = "images/blank.png"}
		if(correct_name === stim[i][3].name){ var feedback4_name = correct_name}else{ var feedback4_name = "images/blank.png"}

		
		
		//var next_trial = {cue: cues[out_x_seq[i]], stim1: stim[0], stim2: stim[1] , stim3: stim[2], stim4: stim[3], out_cue: out_cue[out_cue_seq[i]],out_x: out_x_loc[out_x_seq[i]] ,out_y: out_y , trial: i};
		var next_trial = {
			cue: stim[i].find(el => el.or === out_x_seq[i]).cue, 
			correct: correct_name, 
			correct_col: stim[i].find(el => el.or === out_x_seq[i]).color,
			correct_or: stim[i].find(el => el.or === out_x_seq[i]).or,
			stim1: stim[i][0].name, 
			stim2: stim[i][1].name, 
			stim3: stim[i][2].name, 
			stim4: stim[i][3].name, 
			out_cue: out_color[out_cue[i].find(el => el.or === out_cue_seq[i]).color].c,
			out_image: out_color[out_cue[i].find(el => el.or === out_cue_seq[i]).color].out_c_image, 
			out_x: out_x_loc[stim[i].findIndex(el => el.or === out_x_seq[i])],
			out_y: out_y, 
			feedback1: feedback1_name, 
			feedback2: feedback2_name, 
			feedback3: feedback3_name, 
			feedback4: feedback4_name, 
			trial: i, 
			phase: phase
			};
			
		trial_stimuli.push(next_trial)
	};

}else{ // if color is predictive 

	var correct_name = stim[0].find(el => el.color === out_x_seq[0]).name

	if(correct_name === stim[0][0].name){ var feedback1_name = correct_name}else{ var feedback1_name = "images/blank.png"}
	if(correct_name === stim[0][1].name){ var feedback2_name = correct_name}else{ var feedback2_name = "images/blank.png"} 
	if(correct_name === stim[0][2].name){ var feedback3_name = correct_name}else{ var feedback3_name = "images/blank.png"}
	if(correct_name === stim[0][3].name){ var feedback4_name = correct_name}else{ var feedback4_name = "images/blank.png"}

	var trial_stimuli = [{
		cue: stim[0].find(el => el.color === out_x_seq[0]).cue, 
		correct: correct_name, 
		correct_col: stim[0].find(el => el.color === out_x_seq[0]).color,
		correct_or: stim[0].find(el => el.color === out_x_seq[0]).or,
		stim1: stim[0][0].name, 
		stim2: stim[0][1].name , 
		stim3: stim[0][2].name, 
		stim4: stim[0][3].name,
		out_cue: out_color[out_cue[0].find(el => el.color === out_cue_seq[0]).or].c, 
		out_image: out_color[out_cue[0].find(el => el.color === out_cue_seq[0]).or].out_or_image, 
		out_x: out_x_loc[stim[0].findIndex(el => el.color === out_x_seq[0])],
		out_y: out_y, 
		feedback1: feedback1_name,
		feedback2: feedback2_name, 
		feedback3: feedback3_name, 
		feedback4: feedback4_name, 
		trial: 0, 
		phase: phase
	}];


	for(var i = trial_stimuli[0].trial + 1; i < out_x_seq.length; i++){
		
		var correct_name = stim[i].find(el => el.color === out_x_seq[i]).name

		if(correct_name === stim[i][0].name){ var feedback1_name = correct_name}else{ var feedback1_name = "images/blank.png"}
		if(correct_name === stim[i][1].name){ var feedback2_name = correct_name}else{ var feedback2_name = "images/blank.png"} 
		if(correct_name === stim[i][2].name){ var feedback3_name = correct_name}else{ var feedback3_name = "images/blank.png"}
		if(correct_name === stim[i][3].name){ var feedback4_name = correct_name}else{ var feedback4_name = "images/blank.png"}

		
		
		//var next_trial = {cue: cues[out_x_seq[i]], stim1: stim[0], stim2: stim[1] , stim3: stim[2], stim4: stim[3], out_cue: out_cue[out_cue_seq[i]],out_x: out_x_loc[out_x_seq[i]] ,out_y: out_y , trial: i};
		var next_trial = {
			cue: stim[i].find(el => el.color === out_x_seq[i]).cue, 
			correct: correct_name, 
			correct_col: stim[i].find(el => el.color === out_x_seq[i]).color,
			correct_or: stim[i].find(el => el.color === out_x_seq[i]).or,
			stim1: stim[i][0].name, 
			stim2: stim[i][1].name, 
			stim3: stim[i][2].name, 
			stim4: stim[i][3].name, 
			out_cue: out_color[out_cue[i].find(el => el.color === out_cue_seq[i]).or].c,
			out_image: out_color[out_cue[i].find(el => el.color === out_cue_seq[i]).or].out_or_image, 
			out_x: out_x_loc[stim[i].findIndex(el => el.color === out_x_seq[i])],
			out_y: out_y, 
			feedback1: feedback1_name, 
			feedback2: feedback2_name, 
			feedback3: feedback3_name, 
			feedback4: feedback4_name, 
			trial: i, 
			phase: phase
			};
			
		trial_stimuli.push(next_trial)
	};

};


return(trial_stimuli);

};