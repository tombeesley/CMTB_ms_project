function convertEyeToCSV_ExpFivePres
clearvars % clears variables from workspace

experiment = 'FivePres';
outputDir = 'C:\Users\akar9908\OneDrive - The University of Sydney (Staff)\CMTB_ms_project-master\Exp five presents analysis\Exp FivePres Raw Data CSV\AGP\';

script_path = matlab.desktop.editor.getActive; % current directory of the script
cd(fileparts(script_path.Filename)); % change to that directory
rawDir = [cd '\DATA\']; % set Raw file directory

rawFiles = dir(fullfile(rawDir,'*.mat')); % list of all mat files in Raw dir




for s = 1:size(rawFiles,1)
    clear DATA_AGP DATA_AGP_EG % clears previous S data from workspace
    
    load([rawDir rawFiles(s).name]); %load each file in directory
    subNum = split(rawFiles(s).name,".");
    subNum = str2double(subNum{1}(2:end)); % these digits of filename give the subject number
    
    clc; subNum
    missing = 0; eye_tracking = 0;
    
    if exist('DATA_AGP_EG','var') % extract eyegaze data if it exists
       eye_tracking = 1;
        
        for phase = 1:2

            switch phase
                case 1
                    d = DATA_AGP_EG.DEC;
                    outName = 'dec';
                case 2
                    d = DATA_AGP_EG.FB;
                    outName = 'fb';
            end

            listLs = cellfun('size',d,1); listLs = listLs(:,1); % list of the lengths of all cells
            missed_trials = sum(listLs==0);
            
            % break out of phase loop if missing trials
            if(missed_trials > 5 || missing == 1) % if more than 5 missing trials, don't read in eye data 
                missing = 1;
                eye_tracking = 2;
                continue;
            end
            

            
            d = [double(vertcat(d{:,2}))  double(vertcat(d{:,1}))]; % timestamp, X/Y/Validity for left and right eye  
      

            % scale X and Y to pixel values
            d(:,[2 5]) = d(:,[2 5])*1920;
            d(:,[3 6]) = d(:,[3 6])*1080;

            % set validity to 4 for any eye coordinates not on the screen
            d((d(:,2)<0 | d(:,2)>1920),4) = 4;
            d((d(:,5)<0 | d(:,5)>1920),7) = 4;
            d((d(:,3)<0 | d(:,3)>1080),4) = 4;
            d((d(:,6)<0 | d(:,6)>1080),7) = 4;

            % create array of trial numbers
            tNums = zeros(size(d,1),1);
            index = 1;
            for t = 1:size(listLs,1)
                tNums(index:(index-1)+listLs(t)) = t;
                index = index+listLs(t);
            end

            useLeft = d(:,7)==4 & d(:,4)<4; % left eye X/Y columns stay same if only valid or are replaced by right or both
            useRight = d(:,4)==4 & d(:,7)<4;
            useBoth = d(:,4)<4 & d(:,7)<4;
            noEye = d(:,4)==4 & d(:,7)==4;

            d(useRight,[2 3]) = d(useRight,[5 6]); % use right eye
            d(useBoth,[2 3]) = [mean(d(useBoth,[2 5]),2) mean(d(useBoth,[3 6]),2)]; % use both eye
            d(noEye,[2 3]) = NaN;
            d = [d(:,1:3) tNums];
            if phase < 3 % == 1 % center all timestamps to first ts of decision phase
            first_ts = d(1,1);
            end 
            d(:,1) = round((d(:,1) - first_ts)/1000); % calculate ms timestamp and round to integer

            writematrix(d,[outputDir outName '_P' int2str(subNum) '_ExpFivePres'  '.csv']);

        end
    end 
    
    % get basic trial data and P details
    d = DATA_AGP.training_data;
    % relabel animals in training_data by animal_order labels (what ppt
    % actually saw)
    animals = DATA_AGP.Animals_Order;
    d(:,3) = animals(d(:,3)); % replace giver with actual animal
    d(:,5) = animals(d(:,5)); % replace receiver with actual animal
    p = repmat(subNum,size(d,1),1);
    eye_tracking = repmat(eye_tracking,size(d,1),1);
    pres = DATA_AGP.Presents_Order;
    resps = DATA_AGP.responses;
    
    eye_tracking(1) 
    
    d = [num2cell(p) num2cell(eye_tracking) num2cell(d) num2cell(pres) num2cell(resps)];
    
    writetable(cell2table(d),[outputDir 'trialData' '_P' int2str(subNum) '_ExpFivePres' '.csv'], 'WriteVariableNames', 0);
   
    
    
end