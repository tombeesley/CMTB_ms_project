function Extract_Master_Exp9

    clearvars % clears variables from workspace

    experiment = 'FivePres';
    outputDir = 'C:\Users\akar9908\OneDrive - The University of Sydney (Staff)\CMTB_ms_project-master\Exp five presents analysis\Exp FivePres Raw Data CSV\MASTER\';

    script_path = matlab.desktop.editor.getActive; % current directory of the script
    cd(fileparts(script_path.Filename)); % change to that directory
    rawDir = [cd '\DATA\']; % set Raw file directory

    rawFiles = dir(fullfile(rawDir,'*.mat')); % list of all mat files in Raw dir

    for subj = 1:size(rawFiles,1)
        
        s = subj; % different conventions for mine and Lindsay's code
        clear DATA_MASTER % clears previous S data from workspace
        load([rawDir rawFiles(s).name]); %load each file in directory
        subNum = split(rawFiles(s).name,".");
        subNum = str2double(subNum{1}(2:end)); % these digits of filename give the subject number
        
        
        clc; subNum
        
     writetable(cell2table(DATA_MASTER.details),[outputDir 'Master' '_P' int2str(subNum) '_ExpFivePres' '.csv'], 'WriteVariableNames', 0);
    end
end