function ExtractSurveyData_Exp9

    clearvars % clears variables from workspace

    experiment = 'FivePres';
    outputDir = 'C:\Users\akar9908\OneDrive - The University of Sydney (Staff)\CMTB_ms_project-master\Exp five presents analysis\Exp FivePres Raw Data CSV\QST\';
    script_path = matlab.desktop.editor.getActive; % current directory of the script
    cd(fileparts(script_path.Filename)); % change to that directory
    rawDir = [cd '\DATA\']; % set Raw file directory

    rawFiles = dir(fullfile(rawDir,'*.mat')); % list of all mat files in Raw dir

    for s = 1:size(rawFiles,1)
        clear DATA_QST % clears previous S data from workspace

        load([rawDir rawFiles(s).name]); %load each file in directory
        subNum = split(rawFiles(s).name,".");
        subNum = str2double(subNum{1}(2:end)); % these digits of filename give the subject number
        
        clc; subNum

        p = subNum;

        % extract and score ICU

        % raw ICU and STAI for processing in R
        ICU_raw = transpose(DATA_QST{1,1}(:,1)) - 1; % minus 1 to put on 0-3 scale
        ICUrt = sum(DATA_QST{1,1}(:,2))/60000; % sum ind item rts and convert to minutes
        STAI_raw = transpose(DATA_QST{1,2}(:,1)); % repeat above for STAI
        STAIrt = sum(DATA_QST{1,2}(:,2))/60000;
       

        d = [num2cell(p)  num2cell(ICU_raw)  num2cell(ICUrt) num2cell(STAI_raw) num2cell(STAIrt)];

        writetable(cell2table(d),[outputDir 'Qst' '_P' int2str(subNum) '_ExpFivePres' '.csv'], 'WriteVariableNames', 0);

    end
    
end