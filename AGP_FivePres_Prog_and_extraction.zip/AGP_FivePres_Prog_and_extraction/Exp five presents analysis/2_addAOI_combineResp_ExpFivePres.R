rm(list=ls())
library(tidyverse)

load("Exp_FivePres_data.RData")

Experiment<- 'FivePres'

# Define AOIs
cue_AOI_dimensions = c(835,780,1085,1030) # Cue always appears middle bottom
resp_AOI_dimensions = c(35,400,1885,650) # Allow resp AOI to be across all presents
out_AOI_dimensions = c(35,50,1885,300)


checkXYinAOI <- function(x, y, dur, AOI) { # passes the function 3 variables: x,y,and AOI
  return((x>=AOI[1] & y>=AOI[2] & x<=AOI[3] & y<=AOI[4])*dur) # 
}


# add columns to the EG data which state whether each fixation was in the defined AOIs
allEGData <- allEGData %>% 
  # filter "fixations" < 100ms
  filter(dur > 99) %>%
  rowwise() %>% 
  mutate(AOI_cue = checkXYinAOI(x,y,dur,cue_AOI_dimensions),
         AOI_resp = checkXYinAOI(x,y,dur,resp_AOI_dimensions),
         AOI_out = checkXYinAOI(x,y,dur,out_AOI_dimensions)) %>% 
  ungroup()

# summarise AOI time and nFix per period at the trial level  
trialEG <- allEGData %>% 
  group_by(subj,trial,period) %>%
  summarise(AOI_cue = sum(AOI_cue),
            AOI_resp = sum(AOI_resp),
            AOI_out = sum(AOI_out),
            nFix = n()) %>% # number of fixations per period
  pivot_wider(names_from = period, values_from = AOI_cue:nFix, names_prefix = "p") %>% 
  ungroup() %>% 
  # next line fills in missing trial numbers. 
  # N.B. it assumes all trial numbers (1:96) are present in the set
  complete(subj,trial) %>% 
  arrange(subj,trial)

#summarise time of first AOI_out fixation during feedback, at the trial level
first_out_fix <- allEGData %>%
  filter(period == 2, AOI_out > 0) %>%
  group_by(subj,trial) %>%
  slice(1) %>%
  summarise(time = periodLatency) %>%
  ungroup() %>%
  # next line fills in missing trial numbers.
  # N.B. it assumes all trial numbers (1:96) are present in the set
  complete(subj,trial) %>%
  arrange(subj,trial)

# pivot wider the quality data, so that each row is one trial
allQuality <- allQuality %>% 
  group_by(subj) %>%
  pivot_wider(names_from = period, values_from = samples:post_interp_NA, names_prefix = "p")

# combine the three arrays together
agp_dat <- allResponseData %>% 
  select(subj:RT,eye_tracking) %>% # drop location from responses for now
  left_join(trialEG, by = c("subj", "trial")) %>% 
  left_join(first_out_fix,by = c("subj","trial")) %>% # add first_out fix by join rather than mutate
  left_join(allQuality, by = c("subj", "trial")) %>%
  left_join(allMastData[,c(1:9)],by=c("subj")) %>%
  left_join(allQstData[,c("subj",
                          "ICU","ICU_eleven","RT_ICU",
                          "STAI","RT_STAI")],
            by=c("subj"))

# rename first_out_fix join to be consistent with other files
names(agp_dat)[names(agp_dat)=="time"]<-"tOutFix"
  
# create new phase and block variables, and arrange variables
agp_dat <- agp_dat %>%
  group_by(subj) %>%
  mutate(block=ceiling(trial/5),
         subj = paste0(subj,"_Exp",Experiment))



write_csv(agp_dat, "Exp_FivePres_proc_data.csv")
