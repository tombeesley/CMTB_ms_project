%% extinction and renewal experiment
%see protocol for details
function data = quokkaRenewal
    global MainWindow black white grey screenCentreX screenCentreY screenWidth screenHeight colours resourceFolder realVersion pahandle
     stimuliFolder = '\Stimuli\Quokka Stimuli\';
    stimuliFolder = [resourceFolder stimuliFolder];
    %% image set-up
    [dayBackground] = imageSetup([stimuliFolder 'desertUniform.PNG']);
    [nightBackground] = imageSetup([stimuliFolder 'backgroundNight.PNG']);
    [bucketFront,bucketRect]= imageSetup([stimuliFolder 'bucketFront.PNG']);
    [bucketBack] = imageSetup([stimuliFolder 'bucketBack.PNG']);
    [pumpbody,pumpRect] = imageSetup([stimuliFolder 'pumpBody.PNG']);
    [quokka,quokkaRect] = imageSetup([stimuliFolder 'Quokka.PNG']);
    [pumpHandle,pumpHandleRect] = imageSetup([stimuliFolder 'pumpHandle.PNG']);
    [waterDropTexture,waterDropRect] = imageSetup([stimuliFolder 'WaterDrop.PNG']);
    % boxes
    vertOffset = .7;
    %place quokka
    quokkaVertOffset = .72;
    quokkaHoriOffset = -120;
    quokkaRect = CenterRectOnPoint(quokkaRect, screenCentreX+quokkaHoriOffset, screenHeight*quokkaVertOffset);
    %background
    background = [dayBackground nightBackground];
    backgroundRect = [0 0 screenWidth screenHeight];

    %offset handle attachment point from pump image centre
    handleHorizontalOffset = 227*(screenWidth/1920);
    handleVerticalOffset = 182*(screenHeight/1080);
    %response image box
    pumpRect = scaleToScreen(pumpRect,screenWidth,screenHeight);
    pumpRect = CenterRectOnPoint(pumpRect,screenCentreX,screenHeight*vertOffset);
    %bucket front box
    bucketRect = scaleToScreen(bucketRect,screenWidth,screenHeight);
    bucketRect = CenterRectOnPoint(bucketRect,screenCentreX,screenHeight*vertOffset);
    %handlebox
    handleZeroVector = [63, 277];
    pivotOriginX = screenCentreX + handleHorizontalOffset;
    pivotOriginY = screenHeight*vertOffset-handleVerticalOffset;
    pumpHandleRect = scaleToScreen(pumpHandleRect,screenWidth,screenHeight);
    pumpHandleRect = CenterRectOnPoint(pumpHandleRect,pivotOriginX, pivotOriginY);
    %responsebox
    responseBoxRect = pumpHandleRect;
    responseBoxRect(1) = (pumpHandleRect(3)-pumpHandleRect(1))/2+pumpHandleRect(1);
    responseBoxRect(2) = (pumpHandleRect(4)-pumpHandleRect(2))*4/5+pumpHandleRect(2);
    % waterDrop box
    waterDropRect = scaleToScreen(waterDropRect,screenWidth,screenHeight);
    waterDropRect = CenterRectOnPoint(waterDropRect,screenCentreX,screenHeight*vertOffset);
    %% sound setup
    InitializePsychSound(1);
    [waterDropSound, freq] = getWavedata([stimuliFolder 'waterDrop.WAV']);
    nrchannels = 2;
    pahandle = PsychPortAudio('Open', [], [], 1, freq, nrchannels);
    PsychPortAudio('FillBuffer', pahandle, waterDropSound);
    %% keyboard setup
    RestrictKeysForKbCheck(KbName('space'));
    ShowCursor('Arrow');
    %% Instructions
    instructionText = ['In this task we would like you to help Quentin the Quokka who is lost in the desert.'...
        '\n Quentin has found water pumps in the desert, but he needs your help to pump them.'...
        '\n In order to operate a pump, click on the handle of a pump and drag it up,'...
        '\n When you have lifted it all the way it will lock into place and you will need to release the mouse.'...
        '\n\n Operating the pump may produce a drop of water that Quentin will collect in a bucket.'...
        '\n However, some pumps take time to refill, so you will not get a water drop every time.'...
        '\n Quentin will sometimes decide that a pump does not make enough water, and he will move on to a new pump.'...
        '\n\n Your task is to collect as much water as possible to help Quentin live in the desert.'...
        '\n Once you have understood these instructions, please put on your headphones and press the space key to continue.'];
    %Screen('DrawTexture', MainWindow, background,[],backgroundRect);
    Screen('TextFont',MainWindow,'Calibri');
    DrawFormattedText(MainWindow, instructionText,'center', 'center', black,[],[],[],2);
    Screen('Flip',MainWindow);
    %wait for space
    KbWait([],2);
    %% task variable declaration
    %text location control
        scoreTextLocation = screenHeight*vertOffset + 126*screenHeight/1080;
    %set pump colour
    %set pump colours
        colourSelect = randperm(6);
        colourMod = cell(2);
        for cellIdx = 1:2
            colourMod{cellIdx} = colours(colourSelect(cellIdx), :);
        end
    %movementvars
        verticalLocation = screenHeight*vertOffset;
        fallDist = (80/540)*(pumpRect(4)-pumpRect(2)) - 10;%x/540 x is number of pixels on the source image for which fall is required 540 is the pixel height, this is scaled to the scaled box for the relevant in this code
        speed = 3; %takes 19 frames for the drop to fall (on my laptop screen) 26 on test comp.
        angle = 0;
        maxAngle = -48;
        armLifted = 0;
        rotationSpeed = 1.7; %takes 23 frames to do each direction of movement on the lever 46 total
        waterDropFrameDelay = 0; %wait until the loop has only 26 frames left (+ some error)
        isClickingOnLever = 0;
    %rft rate control
        intervalVariation = 1.5; %testValue
        IntervalSchedule = 4;
    % pump identity control
        nPumps = 2; %each of the seperately trained responses
        pumpOrder = randperm(nPumps);
        pumpIdx = 1;
        pump = pumpOrder(pumpIdx);  
    % phase control
        phase = 1;
        nPhases = 3;
        if realVersion
            trainRftNs = [17 23]; 
            extinctionDuration = 100;
            renewalDuration = 20;
        else
            trainRftNs = [10 10]; 
            extinctionDuration = 15;
            renewalDuration = 10;
        end
        rftsGiven = zeros(1,nPumps);
        trainRftNVec = randi(trainRftNs, [1 nPumps]);
        extinctionEndTime = ones(1,nPumps);
        extinctionEndTime = extinctionEndTime*inf;
        pumpEndTime = extinctionEndTime;
    %context control
        testContexts = randi([1 2], [1 nPumps]);
        contextMat = [testContexts(1) testContexts(1) testContexts(1); testContexts(2) 3-testContexts(2) testContexts(2)]; 
    %Data control
        responseIdx = ones(nPumps,nPhases);
        responseAllowanceTrain = round(max(trainRftNs)*IntervalSchedule*1.2); %fastest clicker in prior experiment clicked < 1.2 times a second, and you need interval schedule * click rate * reward criteria clicks to finish training
        responseAllowanceExtinction = round(extinctionDuration*1.2);
        responseAllowanceRenewal = round(renewalDuration*1.2);
        data.responses{1} = NaN(responseAllowanceTrain, nPumps); % max number of clicks, ntests 
        data.responses{2} = NaN(responseAllowanceExtinction, nPumps); 
        data.responses{3} = NaN(responseAllowanceRenewal, nPumps);
        rftTimes = NaN(nPumps, max(trainRftNs));
    %first reward control
        showOutcome = 0;
        recordReward = 0;
        interval = normrnd(IntervalSchedule,intervalVariation);
        interval(interval < 0) = 0;
        nextRewardTime = GetSecs + interval;
    %experiment cap
        startTimes = NaN(nPhases,nPumps);
        startTimes(1,pump) = GetSecs;
        experimentCutOut = startTimes(1,pump) + 60*20;
        currentTime = GetSecs;
    %% task loop
    % set background to grey for task
    Screen('FillRect',MainWindow,grey);
    
    while pumpIdx < nPumps + 1 && currentTime < experimentCutOut
        %% determine phase
        currentTime = GetSecs;
        previousPhase = phase;
        if rftsGiven(pump) < trainRftNVec(pump)
           phase = 1;
        else
            if currentTime < extinctionEndTime(pump)  %if the current time is less than the extinction duration plus the time at which the final training reward occurred.
                phase = 2;
            else
                phase = 3;
            end
        end
        currentPhase = phase;
        %determine context and show transition
        if previousPhase ~= currentPhase 
            %control contexts
            if contextMat(pump,previousPhase) ~= contextMat(pump,currentPhase) 
                if contextMat(pump,previousPhase) == 1
                    instructionText = 'Quentin asks you to take a break, Night falls...';
                else
                    instructionText = 'Quentin asks you to take a break, the sun rises...';
                end
                DrawFormattedText(MainWindow, instructionText,'center', 'center', black,[],[],[],2);
                Screen('Flip',MainWindow);
                WaitSecs(5);
            end
            startTimes(phase, pump) = GetSecs;
        end
        if previousPhase == 1 && currentPhase == 2
            extinctionEndTime(pump) = GetSecs + extinctionDuration;
        end
        if previousPhase == 2 && currentPhase == 3
            pumpEndTime(pump) = GetSecs + renewalDuration;
        end
    %% show the screen when nothing is going on
        scoreText = sprintf('Drops:\n %d', rftsGiven(pump));
        Screen('DrawTextures', MainWindow, [background(contextMat(pump, phase)) quokka bucketBack waterDropTexture bucketFront],...
            [],[backgroundRect' quokkaRect' pumpRect' waterDropRect' bucketRect']);
        Screen('DrawTextures', MainWindow, [pumpHandle pumpbody],[],[pumpHandleRect' pumpRect'],[angle 0],[],[], colourMod{pump});

        DrawFormattedText(MainWindow, scoreText,'center',scoreTextLocation, white,[],[],[],2);
        Screen('Flip',MainWindow);

    %% Display click and drag
        [mouseClickX,mouseClickY,mouseButtons] = GetMouse(MainWindow);
        buttonDown = find(mouseButtons);
        %Check if key is down
        if ~isempty(buttonDown) && IsInRect(mouseClickX,mouseClickY,responseBoxRect)
                isClickingOnLever = 1;
        end

        while isClickingOnLever
            if isClickingOnLever == 1
                [mouseClickX,mouseClickY,mouseButtons] = GetMouse(MainWindow);
                mouseVector = [mouseClickX-pivotOriginX mouseClickY-pivotOriginY];
                buttonDown = find(mouseButtons);
            end
            if isempty(buttonDown)
                isClickingOnLever = 0;
            else %calc angle for display from mouse
                mouseAngle = atan2d(handleZeroVector(1)*mouseVector(2)-handleZeroVector(2)*mouseVector(1),handleZeroVector(1)*mouseVector(1)+handleZeroVector(2)*mouseVector(2)); %atan2d(x1*y2-y1*x2,x1*x2+y1*y2)
                if mouseAngle < 0 && armLifted ~= 1
                    angle = mouseAngle;
                end
                if angle <= maxAngle
                    armLifted = 1;
                    angle = maxAngle;
                end
            end

            while armLifted ~= 1 && isClickingOnLever ~= 1 && angle < 0 %return arm if not clicking won't work unless you enter the current while when the angle < 0
                    angle = angle + rotationSpeed;
                    Screen('DrawTextures', MainWindow, [background(contextMat(pump, phase)) quokka bucketBack waterDropTexture bucketFront],[],[backgroundRect' quokkaRect' pumpRect' waterDropRect' bucketRect']);
                    Screen('DrawTextures', MainWindow, [pumpHandle pumpbody],[],[pumpHandleRect' pumpRect'],[angle 0],[],[], colourMod{pump});
                    DrawFormattedText(MainWindow, scoreText,'center',scoreTextLocation, white,[],[],[],2);
                    Screen('Flip',MainWindow);
            end
            Screen('DrawTextures', MainWindow, [background(contextMat(pump, phase)) quokka bucketBack waterDropTexture bucketFront],[],[backgroundRect' quokkaRect' pumpRect' waterDropRect' bucketRect']);
            Screen('DrawTextures', MainWindow, [pumpHandle pumpbody],[],[pumpHandleRect' pumpRect'],[angle 0],[],[], colourMod{pump});
            DrawFormattedText(MainWindow, scoreText,'center',scoreTextLocation, white,[],[],[],2);
            Screen('Flip',MainWindow);
        end
    %%  If arm lifted, arm returns and successful pump events occur
        if armLifted == 1
            liftTime = GetSecs;
            %record response
            data.responses{phase}(responseIdx(pump,phase), pump) = liftTime;
            %control for whether there should be a reward for the action
            if phase == 1 && liftTime > nextRewardTime 
                showOutcome = 1;
                recordReward = 1;
            end
            %display response to the lever being lifted to the top of the arc
            armLiftEventStimuli = 1;
            clickResposeFrameCount = 0;
            while armLiftEventStimuli
                if angle < 0
                    angle = angle + rotationSpeed;
                end
                if angle >= 0
                    armLiftEventStimuli = 0;
                end
                if showOutcome && verticalLocation < screenHeight*vertOffset + fallDist && clickResposeFrameCount > waterDropFrameDelay %if this is a rewarded trial
                    waterDropRect = CenterRectOnPoint(waterDropRect,screenCentreX,verticalLocation);
                    verticalLocation = verticalLocation+speed;
                    if verticalLocation >= screenHeight*vertOffset + fallDist
                        %reset waterDrop location
                        verticalLocation = screenHeight*vertOffset;
                        waterDropRect = CenterRectOnPoint(waterDropRect,screenCentreX,screenCentreY+verticalLocation);
                        %set next reward time
                        interval = normrnd(IntervalSchedule,intervalVariation);
                        if interval < 0
                            interval = 0;
                        end
                        nextRewardTime = GetSecs + interval;
                        %indicate outcome presentation finished
                        showOutcome = 0;
                    end
                end
                clickResposeFrameCount = clickResposeFrameCount + 1;
                Screen('DrawTextures', MainWindow, [background(contextMat(pump, phase)) quokka bucketBack waterDropTexture bucketFront],...
                        [],[backgroundRect' quokkaRect' pumpRect' waterDropRect' bucketRect']);
                Screen('DrawTextures', MainWindow, [pumpHandle pumpbody],[],[pumpHandleRect' pumpRect'],[angle 0],[],[], colourMod{pump});
                DrawFormattedText(MainWindow, scoreText,'center',scoreTextLocation, white,[],[],[],2);
                Screen('Flip',MainWindow);
            end
            armLifted = 0;
            if recordReward
                PsychPortAudio('Start', pahandle, 1, 0, 1);
                %PlaySoundV2(waterDropSound,pahandle)
                rftsGiven(pump) = rftsGiven(pump)+1;
                rftTimes(pump, rftsGiven(pump)) = GetSecs;
                recordReward = 0;
            end
            responseIdx(pump,phase) = responseIdx(pump,phase) + 1;
        end
    %% pump change control
        if GetSecs > pumpEndTime(pump)
            pumpIdx = pumpIdx + 1;
            if pumpIdx < nPumps + 1
                pump = pumpOrder(pumpIdx);
                instructionText = ['Quentin has decided to search for a new pump.'...
                    '\n He will drink some water and store the rest, so you will need to fill up the bucket again.'...
                    '\n please press the space key to continue.'];
                %Screen('DrawTexture', MainWindow, background,[],backgroundRect);
                DrawFormattedText(MainWindow, instructionText,'center', 'center', black, [],[],[],2);
                Screen('Flip',MainWindow);
                %wait for space
                KbWait([],2);
                %set times for trial start
                startTimes(1,pump) = GetSecs;
                %reset score text
                scoreText = sprintf('Drops:\n %d', rftsGiven(pump));
            end
        end
    end
    PsychPortAudio('Close', pahandle);
    
    % set background back to white before returning function
    Screen('FillRect',MainWindow,white);

    
    data.rftTimes = rftTimes;
    data.startTimes = startTimes;
    data.parameters = {nPumps, nPhases, IntervalSchedule, trainRftNVec, extinctionDuration, renewalDuration};
end
