%% initialise program
function [DATA,DATA_EG] = AGP
    global MainWindow TextScale black white grey tobii found_eyetrackers my_eyetracker screenCentreX screenCentreY screenWidth screenHeight studyOrder p_number session screenID colours screenRes resourceFolder dataFolder realVersion runET seed TextSize filePath

    TextScaleAGP = TextScale*1;
    DATA_EG = [];
    
    stimuliFolder = '\Stimuli\AGP Stimuli\';
    stimuliFolder = [resourceFolder stimuliFolder];
    

    out_cond = 1;%input('Cond ---> '); % 1 = .8; 2 = 2.7 
    if ~(out_cond == 1 || out_cond == 2) 
        disp("Not valid condition input")
        return 
    end

    loc_cond = 1; %input('location condition 1 = fixed; 2 = randomized/phase; 3 = randomized/trial--->');
    if ~(loc_cond == 1 || loc_cond == 2  || loc_cond == 3) 
        disp("Not valid condition input")
        return 
    end


    % Define task variables that may change
    % Debugging note: instruction slides only synced when at least 2 blocks
    run_task = 1;
    testing = 1; % run test questions after main task
    surveys = 0; % run questionnaires at the end of AGP task
    nBlocks = 6; % number of times each cue is presented in a phase (block)
    nPhases = 4; % number of phases
    nPresents = 5; % number of presents to choose from. Needs to be EVEN to continue without changing instruction array
    nTrials = nBlocks * nPresents * nPhases; % total number of trials
    nTrialsPerPhase = nBlocks * nPresents; % number of trials within a phase
    nAnimals = 5 + (nPhases * nPresents); % initial animals + nPhases more animals
    PhaseIndex = repelem(1:nPhases,nTrialsPerPhase); % add an index of Phase for present location

    

    % screen setup
    res=[screenWidth screenHeight];
    midx = screenCentreX;
    midy = screenCentreY;

    ShowCursor('Arrow');

    %sound setup
    % WARNING: Most windows 10 computers seem to have default audio as 48KHZ,
    % 2 channel. These audio files are at 44.1KHz and psych sound will throw a
    % compatability error. You will need to change the audio settings on your 
    % computer by going to sound settings (just search sound settings in 
    % taskbar) and click "sound control panel" from the menu on the right. 
    % Click the audio device you will be playing through (e.g., computer 
    % speakers or headphones), go to properties, click the "Advanced" tab 
    % and change the Default format sample rate to "24 bit, 44100Hz (Studio Quality)" 
    % and click apply. Sorry, you will have to google the fix if you are using Macs...
    AssertOpenGL;
    % Import sound files
    [correctSound, freq] = getWavedata([stimuliFolder 'correct2.wav']);
    [incorrectSound, ~] = getWavedata([stimuliFolder 'incorrect2.wav']);
    nrchannels = 2;

    %%%VERSION FOR UPDATED PSYCHTOOLBOX%%%
    % IntializePsychSound and open audio device
    % InitializePsychSound(1);
    % pahandle_correct = PsychPortAudio('Open', [], [], 1, freq, nrchannels);
    % pahandle_incorrect = PsychPortAudio('Open', [], [], 1, freq, nrchannels);
    % % Fill buffer with sound
    % PsychPortAudio('FillBuffer',pahandle_correct,correctSound);
    % PsychPortAudio('FillBuffer',pahandle_incorrect,incorrectSound);


    %OLD PSYCHTOOLBOX COMPATIBLE VERSION%%
    pahandle = PsychPortAudio('Open', [], [], 1, freq, nrchannels);

    % old sdk code
    % eye tracking setup
%     if runET == 1
%         tetio_startTracking; 
%     end
     tempTS = zeros(1,5); % Create array to store timestamps

    %% task parameters
    Fixation_Time = 1; % Sets inter-trial interval (blank screen)

    % Set outcome feedback time depending on condition
    if out_cond == 1
        Feedback_Time = .8; % Now means how long feedback is displayed for  
    elseif out_cond == 2
        Feedback_Time = 2.7;
    end


    % Create all textures
    % button boxes
    OKBtn_size = [150 60];
    ContBtn_size = [140 50];
    ContBtnPos = [res(1)-ContBtn_size(1)-200 res(2)-ContBtn_size(2)-50 res(1)-200 res(2)-50];
    BackBtn_size = [140 50];

    % Placement of Animal stimuli at the top
    A_size = 250;
    A_space = 150;
    A_fromTop = 50; % How far from top of screen
    ATopGrid = zeros(nPresents + 1,4); % [Npresents+1 coords] number of presents + center coords
    for a = 1:nPresents
        ATopGrid(a,1) = (a-1)*A_size + (a-1)*A_space; %left
        ATopGrid(a,3) = ATopGrid(a,1)+A_size; %right
    end
    ATopGrid(1:nPresents,[1 3]) = ATopGrid(1:nPresents,[1 3]) + (res(1) - ATopGrid(nPresents,3))*.5; % centres complete grid horizontally
    ATopGrid(nPresents+1,[1 3]) = [midx-A_size/2 midx+A_size/2]; %centre
    ATopGrid(:,2) = A_fromTop; % Top 
    ATopGrid(:,4) = A_fromTop + A_size; % Bottom

    % Placement of Animal stimuli at the bottom (Grid 1-4 and centre)
    ABotGrid = zeros(nPresents + 1,4);
    ABotGrid(1:nPresents + 1,:) = ATopGrid;
    ABotGrid(:,2) = res(2)-A_fromTop-A_size; % Top 
    ABotGrid(:,4) = res(2)-A_fromTop; %Bottom

    % Placement of presents 
    P_size = 250;
    P_space = 150;
    P_fromTop = 400; % How far from top of screen
    PGrid = zeros(nPresents,4);
    for p = 1:nPresents
        PGrid(p,1) = (p-1)*P_size + (p-1)*P_space; %left
        PGrid(p,3) = PGrid(p,1)+P_size; %right
        PGrid(p,[2 4]) = [P_fromTop P_fromTop + P_size]; % Top / Bottom
    end
    PGrid(:,[1 3]) = PGrid(:,[1 3]) + (res(1) - PGrid(nPresents,3))*.5; % centres complete grid horizontally

    % practice instruction box
    PracLBLsize = [1920 60];
    PracLBL = Screen('OpenOffscreenWindow', MainWindow, [255 255 255], [0 0 PracLBLsize(1) PracLBLsize(2)]);
    Screen('TextSize', PracLBL, round(30 * TextScaleAGP));
    Screen('TextFont', PracLBL, 'Calibri');
    Screen('TextColor',PracLBL, [0 150 0]);
    DrawFormattedText(PracLBL, 'The monkey is giving a present to someone. Click on the present you think the monkey is giving.', 'center', 'center');

    % Create Continue Button Texture
    ContBtn = Screen('OpenOffscreenWindow', MainWindow, [130 130 130], [0 0 ContBtn_size(1) ContBtn_size(2)]);
    Screen('FrameRect', ContBtn, [100 100 100] , [], 5);
    Screen('TextSize', ContBtn, round(30 * TextScaleAGP));
    Screen('TextFont', ContBtn, 'Calibri');
    DrawFormattedText(ContBtn, 'Continue', 'center', 'center', [255 255 255]);


    % Import images
    % Create Animal Textures
    % Importing for 4 phases, then change down to 3 if required
    Animal_Names = cell(25,1);
    Animal(1) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Badger.png']))); Animal_Names{1} = ' Badger';
    Animal(2) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Boar.png']))); Animal_Names{2} = ' Boar';
    Animal(3) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Cheetah.png']))); Animal_Names{3} = ' Cheetah';
    Animal(4) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Deer.png']))); Animal_Names{4} = ' Deer';
    Animal(5) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Elephant.png']))); Animal_Names{5} = ' Elephant';
    Animal(6) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Flamingo.png']))); Animal_Names{6} = ' Flamingo';
    Animal(7) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Fox.png']))); Animal_Names{7} = ' Fox';
    Animal(8) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Giraffe.png']))); Animal_Names{8} = ' Giraffe';
    Animal(9) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Gorilla.png']))); Animal_Names{9} = ' Gorilla';
    Animal(10) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Hippo.png']))); Animal_Names{10} = ' Hippo';
    Animal(11) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Hyena.png']))); Animal_Names{11} = ' Hyena';
    Animal(12) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Lion.png']))); Animal_Names{12} = ' Lion';
    Animal(13) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Moose.png']))); Animal_Names{13} = ' Moose';
    Animal(14) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Owl.png']))); Animal_Names{14} = ' Owl';
    Animal(15) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Pelican.png']))); Animal_Names{15} = ' Pelican';
    Animal(16) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Penguin.png']))); Animal_Names{16} = ' Penguin';
    Animal(17) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Rabbit.png']))); Animal_Names{17} = ' Rabbit';
    Animal(18) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Rhino.png']))); Animal_Names{18} = ' Rhino';
    Animal(19) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Squirrel.png']))); Animal_Names{19} = ' Squirrel';
    Animal(20) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Tiger.png']))); Animal_Names{20} = ' Tiger';
    Animal(21) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Walrus.png']))); Animal_Names{21} = ' Walrus';
    Animal(22) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Crocodile.png']))); Animal_Names{22} = ' Crocodile';
    Animal(23) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Wolf.png']))); Animal_Names{23} = ' Wolf';
    Animal(24) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Zebra.png']))); Animal_Names{24} = ' Zebra';
    Animal(25) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Tucan.png']))); Animal_Names{24} = ' Tucan';

    % If only 3 phases, then cut off extra imports
    if nPhases == 3
       Animal_Names = Animal_Names(1:nAnimals);
       Animal = Animal(1:nAnimals);
    end


    % Create Present Textures
    Present(1) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Present1.png']))); Present_Names{1} = ' balloon';
    Present(2) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Present2.png']))); Present_Names{2} = ' cake';
    Present(3) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Present3.png']))); Present_Names{3} = ' lolly';
    Present(4) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Present4.png']))); Present_Names{4} = ' bear';
    Present(5) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Present5.png']))); Present_Names{5} = ' car';

    % Import instructions slides
    % Check how many slides are in Instructions folder
    image_folder = [stimuliFolder 'Instructions\'];
    a = dir(fullfile(image_folder,'*.jpg')); % check how many instruction slides in folder
    n = numel(a); % get number of instruction files

    % loop over number of instruction files to import them
    for i = 1:n  
        Ftext = [image_folder 'Slide' int2str(i) '.jpg'];
        instStim(i) = Screen('MakeTexture', MainWindow, double(imread(Ftext)));
    end 


    % end creating textures and importing images



    % set up all randomization 

    % randomise which animals are givers and receivers
    x = randperm(nAnimals);
    Animal = Animal(x);
    Animal_Names = Animal_Names(x);
    DATA.Animals_Order = x;
    DATA.Animal_Names = Animal_Names;
    % add practice animals to array AFTER randomizing animals as givers and
    % receivers
    Animal(nAnimals + 1) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Animal_inst_1.png'])));
    Animal(nAnimals + 2) = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'Animal_inst_2.png'])));



    % randomise present locations
    % loc_cond 2 and 3 might not work with 5 presents
    if loc_cond == 1 % Present location stays fixed throughout experiment
        PresentMatrix = repmat(randperm(nPresents),nTrials,1);% make a present location matrix for consistency between conditions (rows are same)
        Present_Names = Present_Names(PresentMatrix); % make a present location matrix for consistency between conditions
        DATA.Presents_Order = PresentMatrix;
    elseif loc_cond == 2 % present location is different for each phase
        PresentMatrix = RandomisePresents(nPresents,"ByPhase",[]);
        PresentMatrix = PresentMatrix(randperm(nPresents,nPhases),:); % Only sample nPhases rows of matrix
        PresentMatrix = PresentMatrix(PhaseIndex,:); % use phase index to expand matrix for length consistency across conditions
        Present_names = Present_Names(PresentMatrix); 
        DATA.presents_order = PresentMatrix;
    elseif loc_cond == 3 % randomise present location for each trial
        PresentMatrix = RandomisePresents(nPresents,"ByTrial",nTrials);
        Present_names = Present_Names(PresentMatrix);
        DATA.presents_order = PresentMatrix;
    end


    %get the trial structure
    blocks = repelem(nBlocks,nPhases); % 6 repeats of cues in each stage
    [TT, TTtest_animals, TTtest_presents] = SetTrialsByBlock(blocks); % make the trial order
    TT = [TT, PhaseIndex(:)]; % index phase in data file

    % Set instructions schedule
    % need to check this when blocks are changed
    % Current code will only work when only 1 midphase break instructions
    % slides 1-2 instruction trials
    % slide 3 is generic mid-phase break trial
    % slide 4 is phase 2 instruction
    % slide 5 is phase 3 instruction
    % slide 6 is phase 4 instructions
    instPhase = 1 : 7; % 7 comes from 4 phases + 3 for proper indexing midphases
    instTrials = [1 1; %instructions at trial 1  
          ((nTrialsPerPhase/2 * instPhase(1)) + 1) 3; % mid-phase 1 break 
          ((nTrialsPerPhase/2 * instPhase(2)) + 1) 4; % Phase 2 instructions 
          ((nTrialsPerPhase/2 * instPhase(3)) + 1) 3; % mid-phase 2 break
          ((nTrialsPerPhase/2 * instPhase(4)) + 1) 5; % Phase 3 instructions
          ((nTrialsPerPhase/2 * instPhase(5)) + 1) 3; % mid-phase 3 break
          ((nTrialsPerPhase/2 * instPhase(6)) + 1) 6; % Phase 4 instruction
          ((nTrialsPerPhase/2 * instPhase(7)) + 1) 3]; % mid-phase 4 break  





    %control variables
    pracDone = false; trial = 1;


    %% START OF PROCEDURE

    if run_task == 1
        while trial <= size(TT,1)

            disp(trial);
            % Set Instructions in main task
            insRow = find(instTrials(:,1)==trial); % Should there be an instruction screen before trial (???)   
            if isempty(insRow) == 0 % if there is an instruction
                InstCnt = instTrials(insRow,2); % get relevent instruction slide
                if InstCnt == 1 && pracDone == true % if instruction slide is 1 and practice is done
                    InstCnt = 2; % set instruction slide to 2
                end
                %Present Instructions, wait for keypress
                Screen('DrawTexture', MainWindow, instStim(InstCnt), [], []); % Instruction 1
                Screen('DrawTexture', MainWindow, ContBtn, [], ContBtnPos); % make continue button
                Screen(MainWindow, 'Flip'); % Flip to practice trial
                stimClicked = 0; % clear stimClicked
                while stimClicked == 0 % while mouse hasn't clicked
                    [nClicks, ClickX, ClickY, Btn] = GetClicks(MainWindow, 0); % wait for click
                    stimClicked = checkClickOnStim(ClickX,ClickY,ContBtnPos); % check if click on continue button, 0 if not
                end
            end
            Screen(MainWindow, 'Flip'); % clear screen after instructions
            WaitSecs(Fixation_Time); %blank screen

            % draw stimuli on screen 
            if pracDone == true
                giver = TT(trial,1); % giver read from trial matrix
                pres = find(PresentMatrix(trial,:)==TT(trial,2)); % find trial present in PresentMatrix
                recipient = TT(trial,3); % receiver read from trial matrix
            else
                % practice settings
                giver = nAnimals + 1; % manually assign giver tofor practice
                pres = randi(4);
                recipient = nAnimals + 2; % manually assign recipient for practice
                Screen('DrawTexture',MainWindow,PracLBL,[],[midx-PracLBLsize(1)/2 midy+170 midx+PracLBLsize(1)/2 midy+170+PracLBLsize(2)]);
            end

            Screen('DrawTexture', MainWindow, Animal(giver), [], ABotGrid(nPresents+1,:)); % draw animal 

            for p = 1:nPresents % draw presents
                Screen('DrawTexture', MainWindow, Present(PresentMatrix(trial,p)), [], PGrid(p,:)); 
            end


            %don'tclear flag on
            tempTS(1) = Screen(MainWindow, 'Flip',[],1); % stim On

            PChosen = 0; rNum = 0; tempRs = zeros(10,1); %temp variable to hold 10 responses.

            %imwrite(Screen('GetImage', MainWindow), 'ssTraining.jpg');

            while PChosen ~= pres

                % wait for mouse click on a present
                [nClicks, ClickX, ClickY, Btn] = GetClicks(MainWindow, 0);
                tempTS(2) = GetSecs; % Time Stamp Button Clicked (last storage is OK Button)
                stimClicked = checkClickOnStim(ClickX,ClickY,PGrid);

                % look up what to do on basis of object clicked
                if stimClicked > 0

                    PChosen = stimClicked;
                    if PChosen == pres % If correct present
                        %correct present
                        Screen('DrawTexture', MainWindow, Animal(recipient), [], ATopGrid(pres,:)); % attach outcome to window
                        Screen(MainWindow, 'Flip',[],1); % flip outcome onto display
                        %UPDATED PSYCHTOOLBOX VERSION
                        %PlaySoundV3(pahandle_correct);  %play correct sound 
                        %COMPATIBLE VERSION
                        PlaySoundV2(correctSound,pahandle);  
                    else
                        % incorrect present
                        %UPDATED PSYCHTOOLBOX VERSION
                        %PlaySoundV3(pahandle_incorrect); % play incorrect sound
                        %COMPATIBLE VERSION
                        PlaySoundV2(incorrectSound,pahandle);
                    end
                    rNum = rNum + 1; % add 1 to number of responses
                    if rNum <= size(tempRs,1)
                        tempRs(rNum) = PChosen;
                    end
                end    
            end

            WaitSecs('UntilTime', tempTS(2) + Feedback_Time);
            tempTS(3) = Screen(MainWindow, 'Flip'); % Screen off


            disp(tempTS(3) - tempTS(2));
            if pracDone == true % only record data after practice trial


                if runET == 1
                    % old sdk
%                     [lefteye, righteye, timestamp, trigSignal] = tetio_readGazeData;
%                     DATA_EG.DEC(trial,:) = parseEyeData(timestamp, lefteye, righteye, tempTS(1), tempTS(2));
%                     DATA_EG.FB(trial,:) = parseEyeData(timestamp, lefteye, righteye, tempTS(2), tempTS(3));
                      
                    gaze_data = my_eyetracker.get_gaze_data('flat');
                    leftEye = [gaze_data.left_gaze_point_on_display_area gaze_data.left_gaze_point_validity];
                    rightEye = [gaze_data.right_gaze_point_on_display_area gaze_data.right_gaze_point_validity];
                    timestamp = gaze_data.system_time_stamp;
                    
                  
                    DATA_EG.DEC(trial,:) = parseEyeData(timestamp, leftEye, rightEye, tempTS(1), tempTS(2));
                    DATA_EG.FB(trial,:) = parseEyeData(timestamp, leftEye, rightEye, tempTS(2), tempTS(3));
                end

                %write trial data to the file
                DATA.training_data(trial,1:7) = [trial TT(trial,4) TT(trial,1:3) rNum (tempTS(2) - tempTS(1))*1000];
                DATA.responses(trial,1:size(tempRs)) = tempRs;
            end

            trial = trial + 1;
            if pracDone == false % if practice trial over
                pracDone = true; % set control to true
                trial = 1; % set trial to 1
                Screen('Close',PracLBL) % Clear unneeded texture
            end

        end

        
        % stop eyetracking after all trials are finished
        if runET == 1 
              % Old sdk
%             tetio_stopTracking;  
             my_eyetracker.stop_gaze_data();   
         end

    end
    %% questionnaires
    % break screen prior to questionnaires
    Screen('TextSize', MainWindow, round(30 * TextScaleAGP));
    Screen('TextFont', MainWindow, 'Calibri');
    str1 = 'Please wait...';
    Screen(MainWindow, 'Flip');
    DrawFormattedText(MainWindow, str1, 'center', 'center', [0 0 0]);
    Screen(MainWindow, 'Flip');
    WaitSecs(2); % break before running questionnaires

    if(testing==1)

    % Create UNDO Button Texture
    UNDOButton = Screen('OpenOffscreenWindow', MainWindow, [130 130 130], [0 0 OKBtn_size(1) OKBtn_size(2)]);
    Screen('FrameRect', UNDOButton, [100 100 100] , [], 5);
    Screen('TextSize', UNDOButton, round(30 * TextScaleAGP));
    Screen('TextFont', UNDOButton, 'Calibri');
    DrawFormattedText(UNDOButton, 'UNDO', 'center', 'center', [255 255 255]);

    % Create Back Button Texture
    BackBtn = Screen('OpenOffscreenWindow', MainWindow, [130 130 130], [0 0 BackBtn_size(1) BackBtn_size(2)]);
    Screen('FrameRect', BackBtn, [100 100 100] , [], 5);
    Screen('TextSize', BackBtn, round(30 * TextScaleAGP));
    Screen('TextFont', BackBtn, 'Calibri');
    DrawFormattedText(BackBtn, 'Back', 'center', 'center', [255 255 255]);

    % Question mark image
    QM = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'QuestionMark.png'])));



    %%%%%%%%%%%%%%%%
    %%%% TEST 1%%%%%
    %%%%%%%%%%%%%%%%


        % Redraw top animals as smaller for better display
        % create grids based on up to 4 phases 

        % WARNING: Grids will need to be changed if experiment lasts more than 4 phases
        % "a" would loops need to be extended and grid indices changed 


% 
%         % Placement of Animal stimuli at the top
%         A_size = 150;
%         A_space = 150;
%         A_fromTop = 75; % How far from top of screen
%         ATopGrid = zeros(6,4); % Bottom row for storing centre coords, doesn't seem to be used at all
%         % define relative positions of QMs/animals on top of screen
%         for a = 1:5
%             ATopGrid(a,1) = (a-1)*A_size + (a-1)*A_space; %left 
%             ATopGrid(a,3) = ATopGrid(a,1)+A_size; %right
%         end
%         ATopGrid(1:5,[1 3]) = ATopGrid(1:5,[1 3]) + (res(1) - ATopGrid(5,3))*.5; % centres complete grid horizontally
%         ATopGrid(6,[1 3]) = [midx-A_size/2 midx+A_size/2]; %centre
%         ATopGrid(:,2) = A_fromTop; % Top 
%         ATopGrid(:,4) = A_fromTop + A_size; % Bottom
% 
% 
% 
%         Screen('DrawTexture', MainWindow, instStim(7), [], []); % Instructions
%         Screen('DrawTexture', MainWindow, ContBtn, [], ContBtnPos);
%         Screen(MainWindow, 'Flip');
%         stimClicked = 0; % sets stimClicked to 0 
%         %show instructions until continue button is clicked
%         while stimClicked == 0
%             [~, ClickX, ClickY, ~] = GetClicks(MainWindow, 0); % wait for click
%             stimClicked = checkClickOnStim(ClickX,ClickY,ContBtnPos);
%         end
% 
%         %Creates grid for training animals  LTRB
%         %Up to 20 animals
%         sizeG = 150;
%         spaceGx = 20;
%         APickGrid = zeros(20,4); % change if more than 4 phases
%         % sets L and R of animal grid areas
%         for a = 1:5
%             APickGrid(a,1) = (a-1)*sizeG + (a-1)*spaceGx; %left
%             APickGrid(a,3) = APickGrid(a,1)+sizeG; %right
%         end
%         APickGrid(6:20,:) = repmat(APickGrid(1:5,:),3,1); % change if more than 4 phases
%         APickGrid(:,[1 3]) = APickGrid(:,[1 3]) + (res(1) - APickGrid(5,3))*.5; % centres complete grid horizontally
% 
% 
%         % sets the top and bottom for each animal grid based on 5 per row
%         % adjust if more than 4 phases
%         APickGrid(1:5,[2 4]) = repmat([res(2)-sizeG*4 res(2)-sizeG*3],5,1);
%         APickGrid(6:10,[2 4]) = repmat([res(2)-sizeG*3 res(2)-sizeG*2],5,1);
%         APickGrid(11:15,[2 4]) = repmat([res(2)-sizeG*2 res(2)-sizeG*1],5,1);
%         APickGrid(16:20,[2 4]) = repmat([res(2)-sizeG*1 res(2)],5,1);
%         APickGrid = round(APickGrid);
% 
%         % Clear APickGrid any rows that aren't needed (for debugging)
%         APickGrid = APickGrid(1:nAnimals,:);
% 
%         % test 1 arrow texture, size and positions
%         Arrow = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'arrow.png'])));
%         arrSize = [75 50];
%         arrPos = zeros(4,4); % change if more than 4 phases
%         arrPos(1,:) = [ATopGrid(1,3)+A_space/2-arrSize(1)/2 ATopGrid(1,2)+A_size/2-arrSize(2)/2 ATopGrid(1,3)+A_space/2+arrSize(1)/2 ATopGrid(1,2)+A_size/2+arrSize(2)/2];
%         arrPos(2,[1 3]) = [ATopGrid(2,3)+A_space/2-arrSize(1)/2 ATopGrid(2,3)+A_space/2+arrSize(1)/2];
%         arrPos(3,[1 3]) = [ATopGrid(3,3)+A_space/2-arrSize(1)/2 ATopGrid(3,3)+A_space/2+arrSize(1)/2];
%         arrPos(4,[1 3]) = [ATopGrid(4,3)+A_space/2-arrSize(1)/2 ATopGrid(4,3)+A_space/2+arrSize(1)/2];
%         % duplicate y positions for arrows
%         arrPos(2,[2 4]) = arrPos(1,[2 4]); arrPos(3,[2 4]) = arrPos(1,[2 4]); arrPos(4,[2 4]) = arrPos(1,[2 4]); 
% 
%         % test 1 present size and positions
%         presSize = [100 100];
%         presPos = zeros(4,4);
%         presPos(1,:) = [ATopGrid(1,3)+A_space/2-presSize(1)/2 arrPos(1,2)-presSize(2)-10 ATopGrid(1,3)+A_space/2+presSize(1)/2 arrPos(1,2)-10];
%         presPos(2,[1 3]) = [ATopGrid(2,3)+A_space/2-presSize(1)/2 ATopGrid(2,3)+A_space/2+presSize(1)/2];
%         presPos(3,[1 3]) = [ATopGrid(3,3)+A_space/2-presSize(1)/2 ATopGrid(3,3)+A_space/2+presSize(1)/2];
%         presPos(4,[1 3]) = [ATopGrid(4,3)+A_space/2-presSize(1)/2 ATopGrid(4,3)+A_space/2+presSize(1)/2];
%         % duplicate y positions for arrows
%         presPos(2,[2 4]) = presPos(1,[2 4]); presPos(3,[2 4]) = presPos(1,[2 4]); presPos(4,[2 4]) = presPos(1,[2 4]);
% 
%         bs = [150 60]; % UNDO and Cont button sizes for Test 1
%         UNDOBtnPos = [res(1)-bs(1)-100 midy+120 res(1)-100 midy+120+bs(2)]; 
%         ContBtnTestPos = [res(1)-bs(1)-100 midy+200 res(1)-100 midy+200+bs(2)]; 
% 
%         undo = nAnimals + 1; % row index of undo button in newChoice
%         cont = nAnimals + 2; % row index of cont button in newChoice
% 
%         gridOrder = randperm(nAnimals); % random arrangement of animals to the grid, fixed across trials
%         DATA.test1_gridOrder = gridOrder;
% 
% 
%         for trial = 1:size(TTtest_animals,1) % loop over number of presents
% 
%             Screen(MainWindow, 'Flip');
%             WaitSecs(Fixation_Time); %blank screen 
%             finishedTrial = false;
% 
%             while finishedTrial == false
% 
%                 % draw stimuli on screen 
%                 for a = 1:(nPhases + 1)
%                     Screen('DrawTexture', MainWindow, QM, [], ATopGrid(a,:)); % qusetion mark
%                 end
%                 for a = 1:nPhases
%                     Screen('DrawTexture', MainWindow, Arrow, [], arrPos(a,:)); % arrows
%                     Screen('DrawTexture', MainWindow, Present(TTtest_presents(trial)), [], presPos(a,:)); % arrows
%                 end
%                 for a = 1:nAnimals
%                     Screen('DrawTexture', MainWindow, Animal(gridOrder(a)), [], APickGrid(a,:)); % grid of animals
%                 end  
% 
% 
%                 Screen('TextSize', MainWindow, round(30 * TextScaleAGP));
%                 Screen('TextFont', MainWindow, 'Calibri');
%                 DrawFormattedText(MainWindow, strjoin({'Select any of the',num2str(nAnimals),'animals'}), 100, midy, [0 0 0]);
%                 DrawFormattedText(MainWindow,  'in the order they', 100, midy+30, [0 0 0]);
%                 DrawFormattedText(MainWindow, cell2mat(strcat('received the ', Present_Names(TTtest_presents(trial)))), 100, midy+60, [0 0 0]);
% 
%                 % why does this stim-on call have don'tclear flagged?
%                 tempTS(1) = Screen(MainWindow, 'Flip',[],1); % stim On   
% 
%                 numChosen = 0; % keeps track of how many stim are clicked on
%                 AChosen = zeros(1,(nPhases + 1)); % record of which animals are picked.
%                 while numChosen <= (nPhases + 1) % until all animals picked
% 
%                     % wait for mouse click on a present
%                     [~, ClickX, ClickY, ~] = GetClicks(MainWindow, 0); % returns X and Y coords of mouse click
%                     tempTS(2) = GetSecs; % Time Stamp Button Clicked (last storage is OK Button)
% 
%                     % Checks X and Y mouse clicks to see if in different locations
%                     % depending on how many animals chosen so far
%                     if numChosen == 0
%                         % returns location on grid of first animal chosen
%                         newChoice = checkClickOnStim(ClickX,ClickY,APickGrid); % did they click on an animal
%                     elseif numChosen < (nPhases +1)
%                         % returns location of animal on grid or that undo has been
%                         % clicked
%                         newChoice = checkClickOnStim(ClickX,ClickY,[APickGrid; UNDOBtnPos]); % did they click on an animal or undo
%                     elseif numChosen == (nPhases + 1)
%                         % returns animal click or undo button or continue button
%                         newChoice = checkClickOnStim(ClickX,ClickY,[APickGrid; UNDOBtnPos; ContBtnTestPos]); % did they click on an animal, or undo, or continue
%                     end
% 
% 
%                     if newChoice == undo % clicked UNDOBtn, row undo of stimArray
%                         numChosen = 6; % restart trial
%                         AChosen = zeros(1,(nPhases + 1)); % reset animals picked.
%                         Screen(MainWindow, 'Flip'); % flush the back window
%                     elseif newChoice == cont && numChosen == (nPhases + 1) % clicked ContBtn, row cont of stimArray
%                         numChosen = 6; % break out of loop
%                         finishedTrial = true; % trial finished, go to next trial
% 
% 
%                         % if an animal has been picked AND that animal
%                         % already been picked OR all animals picked and undo or continue not clicked 
%                     elseif (newChoice > 0 && sum(AChosen==gridOrder(newChoice))>0) || (numChosen == (nPhases + 1) && newChoice < undo) % picked an existing pick
%                         % incorrect present
%                         %UPDATED PSYCHTOOLBOX VERSION
%                         %PlaySoundV3(pahandle_incorrect); % play incorrect sound
%                         %COMPATIBLE VERSION
%                         PlaySoundV2(incorrectSound,pahandle);
% 
%                         %Something clicked, it's not undo AND not everything has
%                         %been clicked AND animal isn't already in AChosen 
%                     elseif newChoice > 0  &&  newChoice < undo && numChosen < (nPhases + 1) && sum(AChosen==gridOrder(newChoice))==0  % valid pick
%                         numChosen = numChosen + 1; % add one to numChosen
%                         AChosen(numChosen) = gridOrder(newChoice); % add to choices
%                         Screen('DrawTexture', MainWindow, Animal(AChosen(numChosen)), [], ATopGrid(numChosen,:)); % draw animal over Qmark
%                         Screen('FrameRect', MainWindow , [0 0 0] , APickGrid(newChoice,:), 5); % frame the chosen animal in the grid
%                         Screen('DrawTexture', MainWindow, UNDOButton, [], UNDOBtnPos); % add the Undo button
%                         if numChosen == (nPhases + 1)
%                             Screen('DrawTexture', MainWindow, ContBtn, [], ContBtnTestPos); % add the Cont button if last pick
%                         end                 
%                        Screen(MainWindow, 'Flip',[],1);  % supposed to be the don't clear flag
%                     end    
%                 end
% 
%             end
%             %imwrite(Screen('GetImage', MainWindow), 'ssTest2.jpg');
%             tempTS(2) = Screen(MainWindow, 'Flip'); % Stimuli off
% 
%             corResp = AChosen==TTtest_animals(TTtest_presents(trial),1:(nPhases + 1)); % assign animals to right present after randomization
%             %write trial data to the file
%             DATA.test1_data(trial,:) = [trial TTtest_animals(TTtest_presents(trial),1:(nPhases + 1)) AChosen sum(corResp) (tempTS(2) - tempTS(1))*1000];
%         end
% 



        %%%%%%%%%%%%%
        %%% TEST 2%%%
        %%%%%%%%%%%%%
        TTtest_presents = PresentMatrix(1,:);%TTtest_presents(randperm(5)); % reshuffle presents for second test

        Screen('DrawTexture', MainWindow, instStim(8), [], []); % Instructions
        Screen('DrawTexture', MainWindow, ContBtn, [], ContBtnPos);
        Screen(MainWindow, 'Flip');
        stimClicked = 0;
        while stimClicked == 0
            [~, ClickX, ClickY, ~] = GetClicks(MainWindow, 0); % wait for click
            stimClicked = checkClickOnStim(ClickX,ClickY,ContBtnPos);
        end

        % the answer grid for Test 2
        % placeholder question marks?
        sizeAns = 175;
        spaceAnsX = 175;
        spaceAnsY = 5;
        AnsGrid = zeros(25,4); % 25 animals for 4 phases, 5 x 5 grid
        % sets up the left-to-right spacing of the grid (nPhases + 1)
        for a = 1:5
            AnsGrid(a,1) = (a-1)*sizeAns + (a-1)*spaceAnsX; %left
            AnsGrid(a,3) = AnsGrid(a,1)+sizeAns; %right
        end
        AnsGrid(6:25,:) = repmat(AnsGrid(1:5,:),4,1);
        AnsGrid(:,[1 3]) = AnsGrid(:,[1 3]) + (res(1) - AnsGrid(5,3))*.5; % centres complete grid horizontally

        % sets up the top-to-bottom spacing of the answer grid (nPresent rows)
        AnsGrid(1:5,[2 4]) = repmat([spaceAnsY sizeAns+spaceAnsY],5,1);
        AnsGrid(6:10,[2 4]) = repmat([spaceAnsY*2+sizeAns spaceAnsY*2+sizeAns*2],5,1);
        AnsGrid(11:15,[2 4]) = repmat([spaceAnsY*3+sizeAns*2 spaceAnsY*3+sizeAns*3],5,1);
        AnsGrid(16:20,[2 4]) = repmat([spaceAnsY*4+sizeAns*3 spaceAnsY*4+sizeAns*4],5,1);
        AnsGrid(21:25,[2 4]) = repmat([spaceAnsY*5+sizeAns*4 spaceAnsY*5+sizeAns*5],5,1);
        AnsGrid(:,[2 4]) = AnsGrid(:,[2 4]) + 5; % spaces the grid from the top.
        AnsGrid = round(AnsGrid);

        % test 2 arrow texture, size and positions
        Arrow = Screen('MakeTexture', MainWindow, double(imread([stimuliFolder 'arrow.png'])));
        arrSize = [100 50];
        arrPos = zeros(20,4); % change for phases > 4 (nPresents * nPhases arrow grid)
        % sets up the left-to-right spacing of the arrow grid (nPhases)
        for a = 1:4
            arrPos(a,1) = AnsGrid(a,3)+spaceAnsX/2-arrSize(1)/2;
            arrPos(a,3) = arrPos(a,1) + arrSize(1);
        end
        arrPos(5:20,:) = repmat(arrPos(1:4,:),4,1); % Set the left-right of the arrows
        % Set the top-bottom of the arrows (grouped by horizontal orientation)
        arrPos(1:4,[2 4]) = repmat([AnsGrid(1,2)+sizeAns*.7-arrSize(2)/2 AnsGrid(1,2)+sizeAns*.7+arrSize(2)/2],4,1);
        arrPos(5:8,[2 4]) = repmat([AnsGrid(6,2)+sizeAns*.7-arrSize(2)/2 AnsGrid(6,2)+sizeAns*.7+arrSize(2)/2],4,1);
        arrPos(9:12,[2 4]) = repmat([AnsGrid(11,2)+sizeAns*.7-arrSize(2)/2 AnsGrid(11,2)+sizeAns*.7+arrSize(2)/2],4,1);
        arrPos(13:16,[2 4]) = repmat([AnsGrid(16,2)+sizeAns*.7-arrSize(2)/2 AnsGrid(16,2)+sizeAns*.7+arrSize(2)/2],4,1);
        arrPos(17:20,[2 4]) = repmat([AnsGrid(21,2)+sizeAns*.7-arrSize(2)/2 AnsGrid(21,2)+sizeAns*.7+arrSize(2)/2],4,1);


        % test 2 present size and positions
        presSize = [80 80];
        presPos = zeros(20,4);
        for p = 1:4 % sets relative left-right
            presPos(p,[1 3]) = [AnsGrid(p,3)+spaceAnsX/2-presSize(1)/2 AnsGrid(p,3)+spaceAnsX/2+presSize(1)/2];
        end
        presPos(:,:) = repmat(presPos(1:4,:),5,1); % duplicates X positions
        for p = 1:4:20
            presPos(p:p+3,[2 4]) = repmat([arrPos(p,2)-presSize(2)-10 arrPos(p,2)-10],4,1);
        end

        % Placement of Animal stimuli at the bottom (Grid 1-5 and centre)
        sizeBot = 150;
        spaceBotX = 150; spaceBotY = 5;
        BotGrid = zeros(5,4);
        for a = 1:5
            BotGrid(a,1) = (a-1)*sizeBot + (a-1)*spaceBotX; %left
            BotGrid(a,3) = BotGrid(a,1)+sizeBot; %right
        end
        BotGrid(:,[1 3]) = BotGrid(:,[1 3]) + (res(1) - BotGrid(4,3))*.5; % centres complete grid horizontally
        % realign bottom grid based on new 5 present set
        BotGrid(:,[1 3]) = BotGrid(:,[1 3]) - 225; % centres complete grid horizontally
        % set y coords of bottom grid
        BotGrid(:,[2 4]) = repmat([res(2)-sizeBot-spaceBotY res(2)-spaceBotY],5,1);

        bs = [150 60]; % UNDO and Cont button sizes for Test 2
        UNDOBtnPos = [res(1)-bs(1)-100 midy+375 res(1)-100 midy+375+bs(2)];
        ContBtnTestPos = [res(1)-bs(1)-100 midy+455 res(1)-100 midy+455+bs(2)];


        Screen(MainWindow, 'Flip');

        for trial = 1:(nPhases+1) % loop over number of phases + 1


            WaitSecs(Fixation_Time); % pause between trials

            activeSet = [1:5:21 ; 2:5:22 ; 3:5:23 ; 4:5:24; 5:5:25];
            actAnimalsCor = (1:5)+5*(trial-1); % correct sequence of animals
            actAnimals = actAnimalsCor(randperm(5)); % randomise along the bottom
            finishedTrial = false;

            while finishedTrial == false

                % draw stimuli on screen 
                for a = activeSet(trial,:) 
                    Screen('DrawTexture', MainWindow, QM, [], AnsGrid(a,:)); % question mark
                end

                if trial < (nPhases+1)
                    Pcnt = 0;
                    for a = 0+trial:4:19+trial % arrows redrawn on screen from previous trials
                        Screen('DrawTexture', MainWindow, Arrow, [], arrPos(a,:)); % arrows
                        Pcnt = Pcnt + 1; % goes through presents
                        Screen('DrawTexture', MainWindow, Present(TTtest_presents(Pcnt)), [], presPos(a,:)); % presents
                    end
                end
                Screen('FillRect', MainWindow , [255 255 255] , [BotGrid(1,1) BotGrid(1,2) BotGrid(5,3) BotGrid(5,3)]); % blank out the feedback message
                for a = 1:5
                    Screen('DrawTexture', MainWindow, Animal(actAnimals(a)), [], BotGrid(a,:)); % animals
                end

                tempTS(1) = Screen(MainWindow, 'Flip',[],1); % stim On   

                numChosen = 0;
                AChosen = zeros(1,5); % record of which animals are picked.
                while numChosen <= 5 % until all 4 animals picked

                    % wait for mouse click on a present
                    [~, ClickX, ClickY, ~] = GetClicks(MainWindow, 0);
                    tempTS(2) = GetSecs; % Time Stamp Button Clicked (last storage is OK Button)
                    newChoice = checkClickOnStim(ClickX,ClickY,[BotGrid; UNDOBtnPos; ContBtnTestPos]);
                    % look up what to do on basis of object clicked
                    if newChoice == 6 && numChosen > 0 % clicked UNDOBtn
                        numChosen = 6; % restart trial
                        AChosen = zeros(1,5); % reset animals picked.
                    elseif newChoice == 7 && numChosen == 5 % clicked ContBtn
                        numChosen = 6; % break out of loop
                        finishedTrial = true; % trial finished, go to next trial
                    elseif (newChoice > 0 && sum(AChosen==newChoice)>0) || (numChosen == 5 && newChoice < 6) % picked an existing pick
                        % incorrect present
                        %UPDATED PSYCHTOOLBOX VERSION
                        %PlaySoundV3(pahandle_incorrect); % play incorrect sound
                        %COMPATIBLE VERSION
                        PlaySoundV2(incorrectSound,pahandle);
                    elseif newChoice > 0  &&  newChoice < 6 && sum(AChosen==newChoice)==0 && numChosen < 5 % valid pick
                        numChosen = numChosen + 1;
                        AChosen(numChosen) = newChoice; % add to choices
                        Screen('DrawTexture', MainWindow, Animal(actAnimals(newChoice)), [], AnsGrid(activeSet(trial,numChosen),:)); % draw animal
                        Screen('FrameRect', MainWindow , [0 0 0] , BotGrid(AChosen(numChosen),:), 5); % frame the chosen animal in the grid
                        Screen('DrawTexture', MainWindow, UNDOButton, [], UNDOBtnPos); % add the Undo button
                        if numChosen == 5
                            Screen('DrawTexture', MainWindow, ContBtn, [], ContBtnTestPos); % add the Cont button if last pick
                        end
                        Screen(MainWindow, 'Flip',[],1);
                    end    
                end

                if newChoice == 7 % continue button pressed - show correct answers

                    numCor = sum(actAnimals(AChosen)==actAnimalsCor(TTtest_presents));           

                    Screen('FillRect', MainWindow , [255 255 255] , [BotGrid(1,1) BotGrid(1,2) BotGrid(5,3) BotGrid(5,3)]); % feedback grid dimensions
                    Screen('TextSize', MainWindow, round(30 * TextScaleAGP));
                    Screen('TextFont', MainWindow, 'Calibri');
                    DrawFormattedText(MainWindow, ['You got ', int2str(numCor), ' correct. The correct answers will now be set.'], midx-400, res(2)-100, [0 0 0]);
                    tempTS(2) = Screen(MainWindow, 'Flip', [], 1);
                    WaitSecs(1);

                    for a = 1:5
                        Screen('DrawTexture', MainWindow, Animal(actAnimalsCor(TTtest_presents(a))), [], AnsGrid(activeSet(trial,a),:)); % correct answers
                    end

                    WaitSecs(1);

                end

            end

            DATA.test2_data(trial,:) = [trial actAnimals(AChosen) actAnimalsCor(TTtest_presents) numCor (tempTS(2) - tempTS(1))*1000 actAnimals];

        end

    end    

    %UPDATED PSYCHTOOLBOX 
    % Close the audio device:
    % PsychPortAudio('Close', pahandle_correct);
    % PsychPortAudio('Close', pahandle_incorrect);

    %OLD PSYCHTOOLBOX COMPATIBLE
    % Close the audio device:
    PsychPortAudio('Close', pahandle);

    if surveys==1
        %Clear unneeded textures
        Screen('Close',Animal);
        Screen('Close',Present);
        if testing ==1
        Screen('Close',UNDOButton);
        Screen('Close',ContBtn);
        Screen('Close',BackBtn);
        Screen('Close',QM);
        Screen('Close',Arrow);
        end
        %run questionnaires
        DATA.Qdata = RunQuestionnaires;
    end



   

%     if runET == 1 
%         save(filePath,'DATA_EG','-append')
%     end

    % Screen('Preference', 'SkipSyncTests',0);      % Restores Psychtoolbox calibrations
   % Screen('CloseAll');      % Releases all onscreen and offscreen windows from memory
    ShowCursor




    %end

    %% functions
    function detected = checkClickOnStim(x,y,stimArray)

    % takes the x and y coordinate and checks if it is in one of several areas
    % of interest
    % stimArray contains all AOI where each row is a new AOI and the columns
    % represent: [left, top, right, bottom]

    detected = 0; % default is no AOI detected
    for s = 1:size(stimArray,1) %for all AOIs
        checks = [x>stimArray(s,1) y>stimArray(s,2) x<stimArray(s,3) y<stimArray(s,4)]; %this checks the LTRB dimensions of the shape.
        if sum(checks)==4 % if all those are "ones"
            detected = s; % that AOI is clicked
            return % break out of loop, since it wont be in any other AOI
        end
    end

    end

    function outData = parseEyeData(TS, left, right, First, Last)
    % old sdk
%     f = tetio_localToRemoteTime(int64(First*10^6));
%     l = tetio_localToRemoteTime(int64(Last*10^6));
% 
%     vr = (TS>f)&(TS<l); % valid rows
% 
%     RawEG =  {[left(vr,:) right(vr,:)] TS(vr)};
% 
%     outData = RawEG;

        f = int64(First*10^6);
        l = int64(Last*10^6);

        vr = (TS>f)&(TS<l); % valid rows

        RawEG =  {[left(vr,:) right(vr,:)] TS(vr)};

        outData = RawEG;

    end 
% save data from AGP to master data file
end    