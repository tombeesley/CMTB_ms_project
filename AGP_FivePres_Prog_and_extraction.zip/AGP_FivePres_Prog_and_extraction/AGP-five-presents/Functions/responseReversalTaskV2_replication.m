%% response reversal experiment
%discrimination task between 2 stimuli displayed on the screen
%response input left or right key corresponds to screen position of
%stimulus
%response feedback is +/- 100 points
%positive feedback is probabalistic

%tests 6 pairs of stimuli each pair has the following probabilities p(reward|stimulus1) - 
% p(reward|stimulus2):
% 100-0 80-20 60-40 100-0 80-20 60-40
% these probabilities reverse after 40 trials and occur for a further 40 trials.
% an additional set of probabilities (100 - 0, 60 - 40) are reinforced
% continually for 80 trials. 2 sets of stimuli are used to pad out the
% start and end of the experiment so that pairs of test stimuli are always presented
% indispersed with one other set. The order of stimuli is staggered such
% athat reversals and stimulus set changes do not co-occur in each of the
% concurrent sets of stimuli. the order of pairs is randomised.
% trials are self paced
function data = responseReversalTaskV2_replication
   %% window setup
    global MainWindow resourceFolder black white grey colours screenWidth screenHeight 
    
    %% folders    
    stimuliFolder = '\Stimuli\Reversal Stimuli\';
    stimuliFolder = [resourceFolder stimuliFolder];
    %% parameters
    
    %stimuli
    nHoriLocations = 2;
    nVertLocations = 2;
    %text
    scoreY = screenHeight*.75;
    textColour = black;
    taskTextSize = 70;
    %timing
    outcomeTime = .9;
    ITI = .5;
    %rewards
    probabilityMat = [100 0; 80 20; 60 40; 100 NaN; 80 NaN; 60 NaN; 100 NaN; 100 NaN];     % reversing, non-reversing, dummies
    nSubtypePairs = 3; %n reversing and non-reversing  
    stimulusTrialsPerBlock = 40;
    nTrialsRandomisedPerWindow = 3;
    totalTrialsPerBlock = 60;
    
    %% keyboard setup
    keys = [KbName('left') KbName('right')];
    HideCursor;
    RestrictKeysForKbCheck(keys);
    %% generate trial order
    nPairs = nSubtypePairs + nSubtypePairs;
    orderReversing = randperm(nSubtypePairs);
    orderReversing = reshape([orderReversing; orderReversing], [1, nSubtypePairs*2]);
    orderNonReversing = nSubtypePairs + randperm(nSubtypePairs);
    orderNonReversing = reshape([orderNonReversing; orderNonReversing], [1, nSubtypePairs*2]);
    blockScheme = zeros(2, nPairs + 1);
    blockScheme(1, 1:nSubtypePairs*2) = orderReversing;
    blockScheme(2, 2:1+nSubtypePairs*2) = orderNonReversing;
    blockScheme(2,1) = nPairs + 1;
    blockScheme(1,end) = nPairs + 2;
    blockScheme(:,end) = blockScheme([2 1], end);

    nTrials = (nPairs)*totalTrialsPerBlock + totalTrialsPerBlock/2;
    randomisationWindows = totalTrialsPerBlock/nTrialsRandomisedPerWindow;
    trialScheme = zeros(1, nTrials);
    for block = 1:nPairs + 1
        pairs = blockScheme(:, block)';
        for windowIdx = 1:randomisationWindows
           sequence = [pairs(1) pairs(1) pairs(2)];
           sequence = sequence(randperm(nTrialsRandomisedPerWindow));
           col = (block-1)*totalTrialsPerBlock + (windowIdx-1)*nTrialsRandomisedPerWindow + 1;
           trialScheme(col:col+nTrialsRandomisedPerWindow -1) = sequence;
        end
    end
    trialScheme = trialScheme(1:nPairs*totalTrialsPerBlock + totalTrialsPerBlock/2);
    %% stimulus control
    %import images
    imageList = dir([stimuliFolder '*.png']);
    imageMat = NaN(1,(nPairs+2)*2);
    for image = 1:(nPairs+2)*2
        imgMat = imread([stimuliFolder imageList(image).name]);
        imageMat(image) = Screen('MakeTexture', MainWindow, imgMat);
    end
    imageMat = Shuffle(reshape(imageMat, [nPairs+2, 2]));
    %setup rectangles
    stimRect = [0,0,size(imgMat, 2), size(imgMat,1)];
    locationMat = NaN(4,nHoriLocations*nVertLocations);
    idx = 0;
    for locationHori = 1:nHoriLocations
        for locationVert = 1:nVertLocations
            idx = idx+1;
            locationMat(:,idx) = CenterRectOnPoint(stimRect, ...
                screenWidth/(nHoriLocations+1)*locationHori, ...
                screenHeight/(nVertLocations+1)*locationVert);
        end
    end
    rects = [1 3];
    % setup colours
    colourMat = Shuffle(colours,2);
    %% experiment control
    trialTypeCounter = zeros(1, size(probabilityMat, 1));
  
    score = 0;
    %% data control
    data.responses = NaN(1,nTrials);
    data.responseTime = NaN(1,nTrials);
    data.rewards = NaN(2, nTrials);
    %% instructions
    instructionText = ['Pairs of animals will appear on the screen. On each go you have to choose one of these animals and the computer will tell you if your choice was correct or wrong.'...
        '\nIf it is correct you will win 100 points. If it is wrong you will lose 100 points.'...
        '\nEach animal will sometimes be correct and sometimes be wrong, but one of the animals will tend to be correct more often than the other one.'...
        '\nFind out which animal is usually correct, and choose that animal every time. Stick with it even if it is occasionally wrong.'...
        '\nAt some point it may change so that the other animal is usually correct, in which case you should choose that one every time.'...
        '\nYou will not need headphones for this task. Press the right arrow key to continue'];
    DrawFormattedText(MainWindow, instructionText,'center', 'center', textColour,[],[],[],2);
    Screen('Flip',MainWindow);
    KbWait([],2);
    instructionText = ['Use the left and right arrow keys to choose animals on the left or right side of the screen.'...
        '\nPress the right arrow key start the task.'];
    DrawFormattedText(MainWindow, instructionText,'center', 'center', textColour,[],[],[],2);
    Screen('Flip',MainWindow);
    KbWait([],2);
    
    %% task loop
    Screen('TextSize', MainWindow, taskTextSize);
    % set background to grey for task
    Screen('FillRect',MainWindow,grey);
    
    for trial = 1:nTrials
        %identify trial type
        trialType = trialScheme(trial);
        trialTypeCounter(trialType) = trialTypeCounter(trialType) + 1;
        %determine if rewards will be given
        block = ceil(trialTypeCounter(trialType)/stimulusTrialsPerBlock);
        prob = probabilityMat(trialType, block);
        %choose locations for stims
        sideSelect = randi([1 2]);
        locations = locationMat(:, [rects(sideSelect)+randi([0 1]), rects(3-sideSelect)+randi([0 1])]);
        %draw stimuli
        Screen('DrawTexture', MainWindow, imageMat(trialType, 1), [], locations(:,1),[],[],[],colourMat(trialType,:));
        Screen('DrawTexture', MainWindow, imageMat(trialType, 2), [], locations(:,2),[],[],[],colourMat(trialType+nPairs+2,:));
        stimulusOnset = Screen('Flip',MainWindow);
        [responseTime, key] = KbWait([],2);
        % record response 
        data.responseTime(trial) = responseTime - stimulusOnset;
        key(keys(sideSelect))
        if key(keys(sideSelect)) %is stimulus 1 is located at sideselect
            reward = randi([0 100]) < prob;
            data.responses(trial) = 1;
            data.rewards(1,trial) = reward;
        elseif key(keys(3-sideSelect)) % is stimulus 2
            reward = randi([0 100]) < 100-prob;
            data.responses(trial) = 2;
            data.rewards(2,trial) = reward;
        end
        % draw outcome
        if reward
            outcomeText = 'you win 100 points';
            score = score + 100;
        else
            outcomeText = 'you lose 100 points';
            score = score - 100;
        end
        scoreText = sprintf('current score: %d', score);
        DrawFormattedText(MainWindow, outcomeText,'center', 'center', textColour,[],[],[],2);
        DrawFormattedText(MainWindow, scoreText,'center', scoreY, textColour,[],[],[],2);
        outcomeOnset = Screen('Flip',MainWindow);
        outcomeOffset = Screen('Flip', MainWindow, outcomeOnset + outcomeTime);
        Screen('Flip', MainWindow, outcomeOffset + ITI);
    end
    
    % return background to white before returning function
    Screen('FillRect',MainWindow,white);
    
    data.trialOrder = trialScheme;
end

