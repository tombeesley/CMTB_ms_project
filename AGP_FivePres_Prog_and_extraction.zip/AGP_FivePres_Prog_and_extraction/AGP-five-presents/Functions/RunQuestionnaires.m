function dataOut = RunQuestionnaires

res=[1920 1080];
midx = res(1)/2;
midy = res(2)/2;

Qdata = cell(1,4);

% % MainWindow for experiment
global MainWindow TextScale
Screen(MainWindow, 'Flip'); % blank screen

% positioning buttons on screen
btn_Size = [250 80];
btn_Pos = zeros(4,4);
btn_Pos(1,:) = [midx-2*btn_Size(1)-150 midy+200  midx-btn_Size(1)-150 midy+200+btn_Size(2)];
btn_Pos(2,:) = [midx-btn_Size(1)-50 midy+200  midx-50 midy+200+btn_Size(2)];
btn_Pos(3,:) = [midx+50 midy+200  midx+btn_Size(1)+50 midy+200+btn_Size(2)];
btn_Pos(4,:) = [midx+btn_Size(1)+150 midy+200  midx+2*btn_Size(1)+150 midy+200+btn_Size(2)];
btn_Pos(5,:) = [midx-btn_Size(1)/2 midy+200 midx+btn_Size(1)/2 midy+200+btn_Size(2)];

Screen('TextFont', MainWindow, 'Calibri');
ShowCursor('Arrow');
    
for qList = 1:2 % only run ICU and STAI
    
    
    Qn = getQuestionnaire(qList);
       
    % create button labels
    Screen('TextSize', MainWindow, round(25*TextScale));
    for b = 1:4
        btn(b) = Screen('OpenOffscreenWindow', MainWindow, [200 200 200], [0 0 btn_Size(1) btn_Size(2)]);
        Screen('FrameRect', btn(b), [0 0 0] , [], 5);   
        DrawFormattedText(btn(b), cell2mat(Qn(b,2)), 'center', 'center', [0 0 0]);
    end
    btn(5) = Screen('OpenOffscreenWindow', MainWindow, [200 200 200], [0 0 btn_Size(1) btn_Size(2)]);
    Screen('FrameRect', btn(5), [0 0 0] , [], 5);
    DrawFormattedText(btn(5), 'START', 'center', 'center', [0 0 0]); 
    
    % start questionnaire - display instructions
    Screen('TextSize', MainWindow, round(50*TextScale));
    DrawFormattedText(MainWindow, cell2mat(Qn(1,3)), 'center', midy-200, [0 0 0],80);
    Screen(MainWindow, 'Flip', [], 1); % instructions On
    Screen('DrawTexture', MainWindow, btn(5), [], btn_Pos(5,:)); %START BUTTON
    
    
    
    HideCursor();
    
    %dump mouse clicks during instruction wait period to avoid crashes
    t0 = clock;
    while etime(clock,t0) < 6
    [x,y,buttons,focus,valuators,valinfo] = GetMouse(MainWindow);
    end

    
    ShowCursor('Arrow');
    Screen('Flip',MainWindow); % button on
    
         
    stimClicked = 0;
    while stimClicked == 0
        [nClicks, ClickX, ClickY, Btn] = GetClicks(MainWindow, 0); % wait for click
        stimClicked = checkClickOnStim(ClickX, ClickY, btn_Pos(5,:));
    end
    
    Qdata{qList} = zeros(size(Qn,1),2);
    
    Screen(MainWindow,'Flip');
    WaitSecs(1); % pause between instructions and first question
    
    for q = 1:size(Qn,1)
        stimClicked = 0;    
        Qinfo = ['Questionnaire ', int2str(qList), ' of 2 : Item ', int2str(q), ' of ', int2str(size(Qn,1))];
        Screen('TextSize', MainWindow, round(25*TextScale));
        DrawFormattedText(MainWindow, Qinfo, 'center', midy-450, [0 0 0]); % write header (Q number)       
        
        Screen('TextSize', MainWindow, round(50*TextScale));
        DrawFormattedText(MainWindow, cell2mat(Qn(q,1)), 'center', midy-100, [0 0 0], 50); % write question
        
        % draw buttons
        for b = 1:4
            Screen('DrawTexture', MainWindow, btn(b), [], btn_Pos(b,:));
        end
        tempTS(1) = Screen(MainWindow, 'Flip'); % stim On   
        while stimClicked == 0
            [nClicks, ClickX, ClickY, Btn] = GetClicks(MainWindow, 0); % wait for click
            stimClicked = checkClickOnStim(ClickX, ClickY, btn_Pos(1:4,:));
        end
        tempTS(2) = GetSecs;
        Qdata{qList}(q,:) = [stimClicked (tempTS(2) - tempTS(1))*1000]; % save button response and question RT
        Screen(MainWindow, 'Flip'); % stim Off
        WaitSecs(.5);
    end
   Screen('Close',btn); % clear texture after run
end

dataOut = Qdata;

end

function detected = checkClickOnStim(x,y,stimArray)

% takes the x and y coordinate and checks if it is in one of several areas
% of interest
% stimArray contains all AOI where each row is a new AOI and the columns
% represent: [left, top, right, bottom]

detected = 0; % default is no AOI detected
for s = 1:size(stimArray,1) %for all AOIs
    checks = [x>stimArray(s,1) y>stimArray(s,2) x<stimArray(s,3) y<stimArray(s,4)]; %this checks the LTRB dimensions of the shape.
    if sum(checks)==4; % if all those are "ones"
        detected = s; % that AOI is clicked
        return % break out of loop, since it wont be in any other AOI
    end
end
        
end

function returnQs = getQuestionnaire(whichQ)

switch whichQ
    
    case 1

    % ICU QUESTIONNAIRE
    returnQs = cell(24,3);

    returnQs(1,1) = {'I express my feelings openly.'};
    returnQs(2,1) = {'What I think is "right" and "wrong" is different from what other people think.'};
    returnQs(3,1) = {'I care about how well I do at school or work.'};
    returnQs(4,1) = {'I do not care who I hurt to get what I want.'};
    returnQs(5,1) = {'I feel bad or guilty when I do something wrong.'};
    returnQs(6,1) = {'I do not show my emotions to others.'};
    returnQs(7,1) = {'I do not care about being on time.'};
    returnQs(8,1) = {'I am concerned about the feelings of others.'};
    returnQs(9,1) = {'I do not care if I get into trouble.'};
    returnQs(10,1) = {'I do not let my feelings control me.'};
    returnQs(11,1) = {'I do not care about doing things well.'};
    returnQs(12,1) = {'I seem very cold and uncaring to others.'};
    returnQs(13,1) = {'I easily admit to being wrong.'};
    returnQs(14,1) = {'It is easy for others to tell how I am feeling.'};
    returnQs(15,1) = {'I always try my best.'};
    returnQs(16,1) = {'I apologize (�say I am sorry�) to persons I hurt.'};
    returnQs(17,1) = {'I try not to hurt others� feelings.'};
    returnQs(18,1) = {'I do not feel remorseful when I do something wrong.'};
    returnQs(19,1) = {'I am very expressive and emotional.'};
    returnQs(20,1) = {'I do not like to put the time into doing things well.'};
    returnQs(21,1) = {'The feelings of others are unimportant to me.'};
    returnQs(22,1) = {'I hide my feelings from others.'};
    returnQs(23,1) = {'I work hard on everything I do.'};
    returnQs(24,1) = {'I do things to make others feel good.'};

    returnQs(1,2) = {'Not at all true'};
    returnQs(2,2) = {'Somewhat true'};
    returnQs(3,2) = {'Very true'};
    returnQs(4,2) = {'Definitely true'};
    
    returnQs(1,3) = {'Please read each statement and decide how well it describes you. Mark your answer by clicking the appropriate button for each statement. You must provide an answer for each statement.'};
    
    case 2

    % STAI QUESTIONNAIRE
    returnQs = cell(20,2);
    returnQs(1,1) = {'I feel pleasant.'};
    returnQs(2,1) = {'I feel nervous and restless.'};
    returnQs(3,1) = {'I feel satisfied with myself.'};
    returnQs(4,1) = {'I wish I could be as happy as others seem to be.'};
    returnQs(5,1) = {'I feel like a failure.'};
    returnQs(6,1) = {'I feel rested.'};
    returnQs(7,1) = {'I am "calm, cool, and collected".'};
    returnQs(8,1) = {'I feel that difficulties are piling up so that I cannot overcome them.'};
    returnQs(9,1) = {'I worry too much over something that really doesn''t matter.'};
    returnQs(10,1) = {'I am happy.'};
    returnQs(11,1) = {'I have disturbing thoughts.'};
    returnQs(12,1) = {'I lack self-confidence.'};
    returnQs(13,1) = {'I feel secure.'};
    returnQs(14,1) = {'I make decisions easily.'};
    returnQs(15,1) = {'I feel inadequate.'};
    returnQs(16,1) = {'I am content.'};
    returnQs(17,1) = {'Some unimportant thought runs through my mind and bothers me.'};
    returnQs(18,1) = {'I take disappointments so keenly that I can''t put them out of my mind.'};
    returnQs(19,1) = {'I am a steady person.'};
    returnQs(20,1) = {'I get in a state of tension or turmoil as I think over my recent concerns and interests.'};

    returnQs(1,2) = {'Almost never'};
    returnQs(2,2) = {'Sometimes'};
    returnQs(3,2) = {'Often'};
    returnQs(4,2) = {'Almost always'};
    
    returnQs(1,3) = {'A number of statements which people have used to describe themselves will be shown (one at a time). Read each statement and click the appropriate button to indicate how you generally feel.'};
    
    case 3

    % UPPS QUESTIONNAIRE
    returnQs = cell(45,2);
    
    returnQs(1,1) = {'I have a reserved and cautious attitude toward life.'};
    returnQs(2,1) = {'I have trouble controlling my impulses.'};
    returnQs(3,1) = {'I generally seek new and exciting experiences and sensations.'};
    returnQs(4,1) = {'I generally like to see things through to the end.'};
    returnQs(5,1) = {'My thinking is usually careful and purposeful.'};
    returnQs(6,1) = {'I have trouble resisting my cravings (for food, cigarettes, etc.).'};
    returnQs(7,1) = {'I''ll try anything once.'};
    returnQs(8,1) = {'I tend to give up easily.'};
    returnQs(9,1) = {'I am not one of those people who blurt out things without thinking.'};
    returnQs(10,1) = {'I often get involved in things I later wish I could get out of.'};
    returnQs(11,1) = {'I like sports and games in which you have to choose your next move very quickly.'};
    returnQs(12,1) = {'Unfinished tasks really bother me.'};
    returnQs(13,1) = {'I like to stop and think things over before I do them.'};
    returnQs(14,1) = {'When I feel bad, I will often do things I later regret in order to make myself feel better now.'};
    returnQs(15,1) = {'I would enjoy water skiing.'};
    returnQs(16,1) = {'Once I get going on something I hate to stop.'};
    returnQs(17,1) = {'I don''t like to start a project until I know exactly how to proceed.'};
    returnQs(18,1) = {'Sometimes when I feel bad, I can�t seem to stop what I am doing even though it is making me feel worse.'};
    returnQs(19,1) = {'I quite enjoy taking risks.'};
    returnQs(20,1) = {'I concentrate easily.'};
    returnQs(21,1) = {'I would enjoy parachute jumping.'};
    returnQs(22,1) = {'I finish what I start.'};
    returnQs(23,1) = {'I tend to value and follow a rational, "sensible" approach to things.'};
    returnQs(24,1) = {'When I am upset I often act without thinking.'};
    returnQs(25,1) = {'I welcome new and exciting experiences and sensations, even if they are a little frightening and unconventional.'};
    returnQs(26,1) = {'I am able to pace myself so as to get things done on time.'};
    returnQs(27,1) = {'I usually make up my mind through careful reasoning.'};
    returnQs(28,1) = {'When I feel rejected, I will often say things that I later regret.'};
    returnQs(29,1) = {'I would like to learn to fly an airplane.'};
    returnQs(30,1) = {'I am a person who always gets the job done.'};
    returnQs(31,1) = {'I am a cautious person.'};
    returnQs(32,1) = {'It is hard for me to resist acting on my feelings.'};
    returnQs(33,1) = {'I sometimes like doing things that are a bit frightening.'};
    returnQs(34,1) = {'I almost always finish projects that I start.'};
    returnQs(35,1) = {'Before I get into a new situation I like to find out what to expect from it.'};
    returnQs(36,1) = {'I often make matters worse because I act without thinking when I am upset.'};
    returnQs(37,1) = {'I would enjoy the sensation of skiing very fast down a high mountain slope.'};
    returnQs(38,1) = {'Sometimes there are so many little things to be done that I just ignore them all.'};
    returnQs(39,1) = {'I usually think carefully before doing anything.'};
    returnQs(40,1) = {'Before making up my mind, I consider all the advantages and disadvantages.'};
    returnQs(41,1) = {'In the heat of an argument, I will often say things that I later regret.'};
    returnQs(42,1) = {'I would like to go scuba diving.'};
    returnQs(43,1) = {'I always keep my feelings under control.'};
    returnQs(44,1) = {'I would enjoy fast driving.'};
    returnQs(45,1) = {'Sometimes I do impulsive things that I later regret.'};

    returnQs(1,2) = {'Agree Strongly'};
    returnQs(2,2) = {'Agree Some'};
    returnQs(3,2) = {'Disagree Some'};
    returnQs(4,2) = {'Disagree Strongly'};
    
    returnQs(1,3) = {'You will be presented with a number of statements that describe ways in which people act and think. For each statement, please indicate how much you agree or disagree with the statement. Mark your answer by clicking the appropriate button for each statement. You must provide an answer for each statement.'};
    
    case 4

    % DASS QUESTIONNAIRE
    returnQs = cell(21,2);
    returnQs(1,1) = {'I found it hard to wind down'};
    returnQs(2,1) = {'I was aware of dryness of my mouth'};
    returnQs(3,1) = {'I couldn''t seem to experience any positive feeling at all'};
    returnQs(4,1) = {'I experienced breathing difficulty (eg, excessively rapid breathing, breathlessness in the absence of physical exertion)'};
    returnQs(5,1) = {'I found it difficult to work up the initiative to do things'};
    returnQs(6,1) = {'I tended to over-react to situations'};
    returnQs(7,1) = {'I experienced trembling (eg, in the hands)'};
    returnQs(8,1) = {'I felt that I was using a lot of nervous energy'};
    returnQs(9,1) = {'I was worried about situations in which I might panic and make a fool of myself'};
    returnQs(10,1) = {'I felt that I had nothing to look forward to'};
    returnQs(11,1) = {'I found myself getting agitated'};
    returnQs(12,1) = {'I found it difficult to relax'};
    returnQs(13,1) = {'I felt down-hearted and blue'};
    returnQs(14,1) = {'I was intolerant of anything that kept me from getting on with what I was doing'};
    returnQs(15,1) = {'I felt I was close to panic'};
    returnQs(16,1) = {'I was unable to become enthusiastic about anything'};
    returnQs(17,1) = {'I felt I wasn''t worth much as a person'};
    returnQs(18,1) = {'I felt that I was rather touchy'};
    returnQs(19,1) = {'I was aware of the action of my heart in the absence of physical exertion (eg, sense of heart rate increase, heart missing a beat)'};
    returnQs(20,1) = {'I felt scared without any good reason'};
    returnQs(21,1) = {'I felt that life was meaningless'};

    returnQs(1,2) = {'Never'};
    returnQs(2,2) = {'Sometimes'};
    returnQs(3,2) = {'Often'};
    returnQs(4,2) = {'Almost always'};
    
    returnQs(1,3) = {'Please read each statement and click on the button which indicates how much the statement applied to you over the past week. There are no right or wrong answers. Do not spend too much time on any statement.'};
    
    
end

end
