function [training, test_animals, test_presents] = SetTrialsByBlock(blocks)

b1 = blocks(1); b2= blocks(2); b3 = blocks(3); b4 = blocks(4);

% Training design
% Phase 1
design = [1 1 6 ; 2 2 7 ; 3 3 8 ; 4 4 9 ; 5 5 10]; % col 1 = giver, col 2 = present, col 3 = recipient
N = size(design,1); % number of trials within a block?
training1 = zeros(N*b1,3); % empty matrix for storing randomized trial order
for b = 1:b1 % for b in 1 to number of blocks
    step = (b-1)*N; % (starting row of block) - 1
    temp = design; % rows of giver, pres, receiver
    temp = temp(randperm(N),:); % Randomize row order
    if b > 1 % if block number greater than 1, perm for the later step
        while temp(1,1) == training1(step,1) % stop the first cue of block n being the same as the last cue of block n-1
            temp = temp(randperm(N),:);
        end
    end
    training1(step+1:step+N,:) = temp; % replace rows of training1 with randomized design
    
end

% Phase 2
design = [6 1 11 ; 7 2 12 ; 8 3 13 ; 9 4 14 ; 10 5 15 ];
N = size(design,1);
training2 = zeros(N*b2,3);
for b = 1:b2
    step = (b-1)*N;
    temp = design;
    temp = temp(randperm(N),:);
    if b > 1
        while temp(1,1) == training2(step,1)
            temp = temp(randperm(N),:);
        end
    end
    training2(step+1:step+N,:) = temp;
    
end

% Phase 3
design = [11 1 16 ; 12 2 17 ; 13 3 18 ; 14 4 19 ; 15 5 20];
N = size(design,1);
training3 = zeros(N*b3,3);
for b = 1:b3
    step = (b-1)*N;
    temp = design;
    temp = temp(randperm(N),:);
    if b > 1
        while temp(1,1) == training3(step,1)
            temp = temp(randperm(N),:);
        end
    end
    training3(step+1:step+N,:) = temp;
    
end

% Phase 4
design = [16 1 21 ; 17 2 22 ; 18 3 23 ; 19 4 24 ; 20 5 25];
N = size(design,1);
training4 = zeros(N*b4,3);
for b = 1:b4
    step = (b-1)*N;
    temp = design;
    temp = temp(randperm(N),:);
    if b > 1
        while temp(1,1) == training4(step,1)
            temp = temp(randperm(N),:);
        end
    end
    training4(step+1:step+N,:) = temp;
    
end

training = [training1;training2;training3;training4];

% test 2 design (original, recipient, answer)
test_animals = [1:5:21 ; 2:5:22 ; 3:5:23 ; 4:5:24 ; 5:5:25];
test_presents = randperm(5); % randomize presents for test
