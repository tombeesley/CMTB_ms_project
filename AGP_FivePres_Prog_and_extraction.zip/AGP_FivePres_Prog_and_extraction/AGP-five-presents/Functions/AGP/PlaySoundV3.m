function PlaySoundV3(pahandle)

% 12/10/2018 changes made by lindsay for AGP task:
% initialise sound in the main programme and process wav files and open pa
% handle (in low latency mode)
% stop after playback ('stop',pahandle,1) (the one specifies not to cutoff
% playback!!

% Start audio playback for 'repetitions' repetitions of the sound data,
% start it immediately (0) and wait for the playback to start, return onset
% timestamp.
t1 = PsychPortAudio('Start', pahandle, 1, 0, 1);


% Stop playback:
PsychPortAudio('Stop', pahandle,1);




