function PresentMatrix = RandomisePresents(nPresents,method,nTrials)

if method == "ByPhase"
    % returns a matrix of up to nPresents phases of present locations in which
    % a present never appears at the same location across phases
    % code from accepted answer (Jan) at
    % https://au.mathworks.com/matlabcentral/answers/417-how-do-i-use-randperm-to-produce-a-completely-new-sequence-no-numbers-in-same-place
    PresentMatrix = mod(bsxfun(@plus, randperm(nPresents), transpose(randperm(nPresents))), nPresents) + 1;
elseif method == "ByTrial"
    % returns nTrials x nPresents matrix with a random permutation of
    % present order for each trial
    % method from accepted answer (Andrei Bobrov) at
    % https://au.mathworks.com/matlabcentral/answers/155207-matrix-with-different-randperm-rows
      
    [~, PresentMatrix] = sort(rand(nTrials,nPresents),2);
      
      % If same present order appears in consecutive rows,
      % keep generating new Present Matrixes
      while any(sum(abs(diff(PresentMatrix)),2) == 0)
          [~, PresentMatrix] = sort(rand(nTrials,nPresents),2);
      end
      
end

end