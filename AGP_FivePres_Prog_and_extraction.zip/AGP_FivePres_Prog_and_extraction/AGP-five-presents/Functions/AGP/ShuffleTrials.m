%Shuffle order of trials, without the same cue appearing twice in a row

function [ShuffledTrialMatrix] = ShuffleTrials(design,nReps)
% design: matrix of the four sets of giver, present, receiver
% nReps: How many times to replicate design matrix

TrialMatrix = repmat(design,nReps,1); % matrix of all trials for a phase
nCues = size(design,1); % number of cues


Trials = repelem(1:nCues,nReps); % create vector of Nreps of each cue

Shuffled = Trials(randperm(length(Trials))); % shuffle the Trials vector

% Keep shuffling trials until there are no consecutive trials of same cue
% Quick enough for 24 trials, but gets very inefficient as trial number increases
while any(diff(Shuffled)== 0) 
    Shuffled = Trials(randperm(length(Trials)));
end

ShuffledTrialMatrix = TrialMatrix(Shuffled(:),:); % arrange Trial matrix by new randomized trial order

end