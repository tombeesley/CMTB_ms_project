function [training, test_animals, test_presents] = SetTrialsByPhase(block)

% Design matrix takes into account 
%new randomized present locations across phases

% design = [giver present receiver; giver present receiver; ...]

design1 = [1 1 5; 2 2 6; 3 3 7; 4 4 8];
design = cat(3,design1);

if length(block) >= 2
design2 = [5 1 9; 6 2 10; 7 3 11; 8 4 12];
design = cat(3,design1,design2);
end

if length(block) >= 3
    design3 = [9 1 13 ; 10 2 14 ; 11 3 15 ; 12 4 16];
    design = cat(3,design1,design2,design3);
end    
if length(block) >= 4
    design4 = [13 1 17; 14 2 18; 15 3 19; 16 4 20];
    design = cat(3,design1,design2,design3,design4); 
end



training = [];

for i = 1:length(block)
    % Training design
    % Phase 1
    training_temp = ShuffleTrials(design(:,:,i),block(i)); % creates trialmatrix based on design and repeats in a block  

    training = [training; training_temp]; % bind trial matrix (MATLAB doesn't like growing arrays, so red line, but I would prefer to keep this flexible and it's not so costly now)
end 

% test 2 design (original, recipient, answer)
% based on max of 4 phases
test_animals = [1:4:17 ; 2:4:18 ; 3:4:19 ; 4:4:20];
test_presents = randperm(4); % randomize presents for test
