function [outputRect] = scaleToScreen(inputRect,screenWidth,screenHeight)

outputRect = [inputRect(1)*(screenWidth/1920) inputRect(2)*(screenHeight/1080)...
    inputRect(3)*(screenWidth/1920) inputRect(4)*(screenHeight/1080)];

end