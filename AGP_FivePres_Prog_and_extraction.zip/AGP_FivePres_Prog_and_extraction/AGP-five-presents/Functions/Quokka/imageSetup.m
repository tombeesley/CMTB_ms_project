function [imageTexture,imageBox,imageWidth,imageLength]  = imageSetup(imageName)
[~, ~, alpha] = imread(imageName); %does the image have transparency
global MainWindow;
if isa(alpha,'uint8')
    %if yes make texture and transparency 
     [imageMat, ~,~] = imread(imageName);
     imageMat(:,:,4) = alpha;
     imageTexture = Screen('MakeTexture', MainWindow,imageMat);       
else 
    %if no make texture
     imageMat = imread(imageName);
     imageTexture = Screen('MakeTexture', MainWindow,imageMat);
end
    %make display Box
    [imageWidth, imageLength, ~] =size(imageMat);
    imageBox = [0 0 imageLength imageWidth];
end
