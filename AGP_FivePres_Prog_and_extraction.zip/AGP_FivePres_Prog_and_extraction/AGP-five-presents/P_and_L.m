
close all;
clearvars;
Screen('CloseAll')
%% initialising inputs
global MainWindow TextScale black white grey tobii found_eyetrackers my_eyetracker screenCentreX screenCentreY screenWidth screenHeight studyOrder p_number screenID colours screenRes resourceFolder dataFolder realVersion runET seed TextSize filePath CalibBug
TextScale = 1; % rescale text for computer 250
CalibBug = [];
%folders
app_home = cd;
cd(app_home);
addpath(genpath(strcat(app_home, '\Functions')))
addpath(genpath(strcat(app_home, '\Stimuli')))
runET = 0; % controls running of ET or not
if runET == 1; addpath(genpath('C:\toolbox\Tobii SDK Matlab')); end
resourceFolder = app_home;
dataFolder = '\DATA\';
dataFolder = [resourceFolder dataFolder]; 
%% parameters

screenWidth = 1920; 
screenHeight = 1080;
TextSize = round(25 * TextScale);
colours = [136,233,154; 177,32,96; 35,219,225; 21,81,38; 255,172,236; 86,146,68; 158,55,208; 99,225,24;...
        159,33,8; 205,219,155; 24,81,155; 188,227,51; 126,62,83; 233,173,111; 82,82,82; 160,205,226];%/252;
%% Set Ppt and session details

realVersion = ~input('debugging? (0/1) -->');
if realVersion

    inputError = 1;
  
    while inputError == 1
        inputError = 0;
        
        p_number = input('Participant number  ---> ');
        filePath = [dataFolder 'P' num2str(p_number) '.mat'];
        if exist(filePath, 'file') > 0
            disp(['Data for participant ', num2str(p_number),' already exists']);
            inputError = 1;
        end
    end    
    
    % SET STUDY ORDER HERE
    studyOrder = [1,4]; % AGP, questionnaires
else    
    p_number = 9999;
    studyOrder = [1,4];
end

% clear console of experimenter input
clc;

% generate a random seed using the clock, then use it to seed the random number generator
RandStream.setGlobalStream(RandStream('mt19937ar','seed',sum(100*clock)));
seed = rng;
seed = seed.Seed; % store seed for replicability


%% window setup
if realVersion
  Screen('Preference', 'SkipSyncTests', 0);      % Enables the Psychtoolbox calibrations
else
    Screen('Preference', 'SkipSyncTests', 2);      % Skips the Psychtoolbox calibrations (makes startup faster when debugging)
    fprintf('\n\nEXPERIMENT IS BEING RUN IN DEBUGGING MODE!!!');
end

white = [255,255,255];
black = [0,0,0];
grey = white/2;
screenID = 0;  % Show stimuli on primary monitor
screenRes = [screenWidth screenHeight];
screenCentreX = round(screenWidth/2);
screenCentreY = round(screenHeight/2);

input('Press Enter to start calibration');

%% RUN CALIBRATION
% Run calibration before ppt has to enter any details in case of sync
% problems 

if runET == 1
CalibBug = [];    
    while isempty(CalibBug) 
    clc;
    
    tobii = EyeTrackingOperations();
    found_eyetrackers = tobii.find_all_eyetrackers();
    my_eyetracker = found_eyetrackers(1);
    
    
    
    disp(['Address: ', my_eyetracker.Address])
    disp(['Model: ', my_eyetracker.Model])
    disp(['Name (It''s OK if this is empty): ', my_eyetracker.Name])
    disp(['Serial number: ', my_eyetracker.SerialNumber])
    
    
%     calib = 'a';
%     while ~strcmpi(calib, 'y')
%         calib = input('Type "y" and press Enter after calibration complete --->   ', 's');
%         if isempty(calib); calib = 'a'; end
%     end
    
    
%     
%     [MainWindow] = Screen(screenID, 'OpenWindow',white, [0, 0, screenWidth , screenHeight ]);
%     Screen('Preference', 'VisualDebugLevel', 3);
%     Screen('BlendFunction', MainWindow, 'GL_SRC_ALPHA', 'GL_ONE_MINUS_SRC_ALPHA');
%     
%     Screen('TextFont', MainWindow, 'Calibri');
%     
%     
  GenericCalibration; runET = 1;
    end
    
    clearvars('CalibBug')
end


% allow writing in command line
% Participant demographics input
if realVersion
    clc;
    disp('Please answer each question and press "Enter" to continue.')
    
    % age 
    age = 0;
    while age == 0
        age = input('Enter your age ---> ');
        if isempty(age); age = 0; end
    end
    % sex
    sex = 'a';
    while ~strcmpi(sex, 'm') && ~strcmpi(sex, 'f') && ~strcmpi(sex, 'u')
        sex = input('Enter your sex/gender (f = Female; m = Male; u = My sex/gender cannot be categorised by the options above) --->   ', 's');
        if isempty(sex); sex = 'a'; end
    end
    % handedness
    hand = 'a';
    while ~strcmpi(hand, 'r') && ~strcmpi(hand, 'l') && ~strcmpi(hand, 'b')
        hand = input('Are you left or right handed? (r = Right handed; l = Left handed; b = Both left and right handed) ---> ', 's');
        if isempty(hand); hand = 'a'; end
    end
     % native language ability?
    lang_nat = 'a';
    while ~strcmpi(lang_nat, 'y') && ~strcmpi(lang_nat, 'n')
        lang_nat = input('Was English the first language you learned to read? (y = Yes; n = No) ---> ', 's');
        if isempty(lang_nat); lang_nat = 'a'; end
    end
     
    % current language ability
    lang_cur = 'a';
    while ~strcmpi(lang_cur, 'y') && ~strcmpi(lang_cur, 'n')
        lang_cur = input('Do you currently have adequate proficiency in English?\n(y = You have adequate proficiency in English;\n n = English is not your first language AND\n you''ve been in the UK for less than 10 years AND\n you use an English dictionary often or all the time) ---> ', 's');
        if isempty(lang_cur); lang_cur = 'a'; end
    end
    
else
    age = 9999;
    sex = 9999;
    hand = 9999;
    lang_nat = 9999;
    lang_cur = 9999;
    filePath = [dataFolder 'P' num2str(p_number) '.mat'];
    instructDelay = 0;
end


% create the data file
% initialise data storage
format bank; %output data in easy to read format
DATA_MASTER = []; 
start_time = datestr(now,0);

DATA_MASTER.details = {p_number studyOrder age sex hand lang_nat lang_cur start_time seed};

if runET == 1
DATA_MASTER.details = {p_number my_eyetracker.Model studyOrder age sex hand lang_nat lang_cur start_time seed};
end

save(filePath,'DATA_MASTER', '-v7.3'); % save DATA structure

% Open window again after closing from calibration

InitializePsychSound(1);

[MainWindow] = Screen(screenID, 'OpenWindow',white, [0, 0, screenWidth , screenHeight ]);
Screen('Preference', 'VisualDebugLevel', 3);
Screen('BlendFunction', MainWindow, 'GL_SRC_ALPHA', 'GL_ONE_MINUS_SRC_ALPHA');
Screen('TextFont', MainWindow, 'Calibri');

%Initial instructions
Screen('TextSize', MainWindow, TextSize);
InstructionText = ['Welcome to Personality and Learning.'...
'\n In this session, you will complete two different tasks.'...
'\n There will be one computer-based associative learning task and a series of questionnaires.'...
'\n Please read the instructions for each task and questionnaire carefully, as they have different requirements.'...
'\n At the end of each task, you will be told how many tasks you have remaining and will have the opportunity to take a small break.'...
'\n The total session time will be no longer than 30 minutes.'...
'\n Please let the experimenter know now if you have any questions about the procedure for the session.'...
'\n You may also let the experimenter know if you have any questions about the instructions for specific tasks as you encounter them.'...
'\n Press the space key to start the first task of this session.'];
RestrictKeysForKbCheck(KbName('space'))
DrawFormattedText(MainWindow, InstructionText,'center', 'center', black,[],[],[],2);   
Screen('Flip',MainWindow);
KbWait([],2);

for componentIdx = 1:length(studyOrder)
    
    component = studyOrder(componentIdx);
    if component == 1
        if runET == 1
          my_eyetracker.get_gaze_data('flat');  
          InstructionText = ['In this first task, your eyes will be tracked.'...
        '\n We ask that you please continue to use the chinrest and maintain the same seating position from the calibration task.'...
        '\n You will receive instructions when the eye tracking component of the session has finished, and you will be free '...
        '\n to adjust your seating position from that point.'...
        '\n Press the space key to start the first task of this session.'];
        RestrictKeysForKbCheck(KbName('space'))
        DrawFormattedText(MainWindow, InstructionText,'center', 'center', black,[],[],[],2);   
        Screen('Flip',MainWindow);
        KbWait([],2);

        end
        start_time_AGP = datestr(now,0);
        [DATA_AGP,DATA_AGP_EG] = AGP;
        Screen('Close'); % clear unneeded textures
        end_time_AGP = datestr(now,0);
        % save data
        save(filePath,'DATA_AGP','DATA_AGP_EG','-append')
    end
    if component == 2
        start_time_QUOKKA = datestr(now,0); 
        DATA_QUOKKA = quokkaRenewal;
        Screen('Close'); % clear unneeded textures
        end_time_QUOKKA = datestr(now,0);
        % save data
        save(filePath,'DATA_QUOKKA','-append')
    end
    if component == 3
        start_time_RR = datestr(now,0); 
        DATA_RR = responseReversalTaskV2_replication;
        Screen('Close'); % clear unneeded textures
        end_time_RR = datestr(now,0); 
        % save data
        save(filePath,'DATA_RR','-append')
    end
    
    if component == 4
        % QST instructions
        Screen('TextSize', MainWindow, TextSize);
        InstructionText = ['The next task involves filling out some questionnaires.'...
        '\n Please read the instructions for each questionnaire carefully and take note that the'...
        ' response labels change across different questionnaires.'...
        '\n Press the space key to start the first questionnaire.'];
        RestrictKeysForKbCheck(KbName('space'))
        DrawFormattedText(MainWindow, InstructionText,'center', 'center', black,[],[],[],2);   
        Screen('Flip',MainWindow);
        KbWait([],2);
        
        start_time_QST = datestr(now,0);
        DATA_QST = RunQuestionnaires;
        end_time_QST = datestr(now,0);
        % save data
        save(filePath,'DATA_QST','-append')
    end
    
    if component < length(studyOrder)
        Screen('TextSize', MainWindow, TextSize);
        Screen(MainWindow, 'Flip');
        if component == 1 && runET==1 
            InstructionText = ['Thank you for completing this task.'...
          '\n Your eyes will not be tracked for the remainder of the session, so you may adjust your seating position if desired.'...      
          '\n There are ' num2str(2 - componentIdx) ' more tasks remaining in this session.'...  
          '\n Please take a short break and press the space key when you are ready to continue with the session.'];
        else 
            InstructionText = ['Thank you for completing this task.'...
          '\n There are ' num2str(2 - componentIdx) ' more tasks remaining in this session.'...  
          '\n Please take a short break and press the space key when you are ready to continue with the session.'];
        end     
        RestrictKeysForKbCheck(KbName('space'))
        DrawFormattedText(MainWindow, InstructionText,'center', 'center', black,[],[],[],2);   
        Screen('Flip',MainWindow);
        KbWait([],2);
    end    
end


end_time = datestr(now,0);

DATA_MASTER.details = {p_number studyOrder age sex hand lang_nat lang_cur start_time end_time start_time_AGP end_time_AGP start_time_QST end_time_QST seed};

if runET == 1
DATA_MASTER.details = {p_number my_eyetracker.Model studyOrder age sex hand lang_nat lang_cur start_time end_time start_time_AGP end_time_AGP start_time_QST end_time_QST seed};
end
save(filePath,'DATA_MASTER','-append')

finalInstructionText = ['You have completed the session.'...
      '\n Please inform the experimenter that you are done.'];
DrawFormattedText(MainWindow, finalInstructionText,'center', 'center', black,[],[],[],2);
Screen('Flip',MainWindow);
RestrictKeysForKbCheck(KbName('F10'));
KbWait([],2);
sca;

