
close all;
clearvars;
Screen('CloseAll')
%% initialising inputs
global MainWindow TextScale black white grey tobii found_eyetrackers my_eyetracker screenCentreX screenCentreY screenWidth screenHeight studyOrder p_number session screenID colours screenRes resourceFolder dataFolder realVersion runET seed TextSize filePath CalibBug
TextScale = .75; % rescale text for computer 250

%folders
app_home = cd;
cd(app_home);
addpath(genpath(strcat(app_home, '\Functions')))
addpath(genpath(strcat(app_home, '\Stimuli')))
runET = 1; % controls running of ET or not
if runET == 1; addpath(genpath('C:\toolbox\Tobii SDK Matlab')); end
resourceFolder = app_home;
dataFolder = '\DATA\';
dataFolder = [resourceFolder dataFolder]; 
%% parameters

screenWidth = 1920; 
screenHeight = 1080;
TextSize = round(25 * TextScale);
colours = [136,233,154; 177,32,96; 35,219,225; 21,81,38; 255,172,236; 86,146,68; 158,55,208; 99,225,24;...
        159,33,8; 205,219,155; 24,81,155; 188,227,51; 126,62,83; 233,173,111; 82,82,82; 160,205,226];%/252;
%% Set Ppt and session details

realVersion = ~input('debugging? (0/1) -->');
if realVersion

    inputError = 1;
  
    while inputError == 1
        inputError = 0;
        
        p_number = input('Participant number  ---> ');
        session = input('Which session ---> ');
        filePath = [dataFolder 'P' num2str(p_number) '_S' num2str(session) '.mat'];
        if exist(filePath, 'file') > 0
            disp(['Data for participant ', num2str(p_number),', session ' num2str(session) ' already exists']);
            inputError = 1;
        end
    end    
        
    inputError = 1;
    
    while inputError == 1
        inputError = 0;
        
        taskOrder = input('taskOrder [renewal reversal/reversal renewal] -->'); 
        if ~(taskOrder == 1 || taskOrder == 2) 
            disp("Invalid study order")
            inputError=1;
        end 
    end
    
    % SET STUDY ORDER HERE
    studyOrder = [
        [1,2,3,4],
        [1,3,2,4]
    ];
    studyOrder = studyOrder(taskOrder,:);
else    
    p_number = 9999;
    session = 2;
    studyOrder = [1,2];
end

% clear console of experimenter input
clc;

% generate a random seed using the clock, then use it to seed the random number generator
RandStream.setGlobalStream(RandStream('mt19937ar','seed',sum(100*clock)));
s = rng;
s = s.Seed; % store seed for replicability


%% window setup
if realVersion
  Screen('Preference', 'SkipSyncTests', 0);      % Enables the Psychtoolbox calibrations
else
    Screen('Preference', 'SkipSyncTests', 2);      % Skips the Psychtoolbox calibrations (makes startup faster when debugging)
    fprintf('\n\nEXPERIMENT IS BEING RUN IN DEBUGGING MODE!!!');
end

white = [255,255,255];
black = [0,0,0];
grey = white/2;
screenID = 0;  % Show stimuli on primary monitor
screenRes = [screenWidth screenHeight];
screenCentreX = round(screenWidth/2);
screenCentreY = round(screenHeight/2);

if session == 1 % SHOW CONSENT FORM
    
    [MainWindow] = Screen(screenID, 'OpenWindow',white, [0, 0, screenWidth , screenHeight ]);
    Screen('Preference', 'VisualDebugLevel', 3);
    Screen('BlendFunction', MainWindow, 'GL_SRC_ALPHA', 'GL_ONE_MINUS_SRC_ALPHA');
    Screen('TextFont', MainWindow, 'Calibri');

    
    TextSize_consent = 20 * TextScale;
    Screen('TextSize', MainWindow, TextSize_consent);
    ConsentText = ['PARTICIPANT CONSENT FORM'...
                    '\n - The details of my involvement have been explained to me, and I have been provided with a written Participant Information Statement to keep.'...
                    '\n - I understand the purpose of the study is to investigate the relationship between associative learning and individual differences in personality over time.' ...
                    '\n - I acknowledge that the risks and benefits of participating in this study have been explained to me to my satisfaction.'...
                    '\n - I understand that in this study I will be required to participate in two separate sessions, each taking 75 minutes, where I will complete several computer-based associative learning tasks and complete four self-report\n   questionnaires. I understand that the two sessions will be spaced exactly two-weeks apart and at the same time of day.'...
                    '\n - I understand that my participation may involve eye tracking during completion of some of the computer-based associative learning tasks. I understand that eye tracking only involves recording the estimated location\n   of a person''s gaze on the computer screen and is not a video recording of a person''s face or eyes.'...
                    '\n - I understand that being in this study is completely voluntary.'...
                    '\n - I am assured that my decision to participate will not have any impact on my relationship with the research team or the University of Sydney.'...
                    '\n - I understand that my data will be temporarily re-identifiable with a data key, and that this key will be destroyed at the end of data collection for the experiment or when the SONApsych pool is closed for the semester\n   that I completed the experiment in (whichever happens first). I understand that once the data key has been destroyed, I will not be able to withdraw my data from the study because it has been permanently de-identified.'...
                    '\n - I understand that my information may be used in future research because anonymous data collected in this study will be posted on an online repository to facilitate dissemination of this research and support\n   any reporting resulting from this research. As this data will be licensed for public, I understand that the researchers cannot anticipate or control how it may be used in the future. I understand that I will not be\n   individually identifiable in any publicised data and that data will only be posted after the data key has been destroyed.'...
                    '\n - I understand that I am free to withdraw from this study at any time and that I can choose to withdraw any information I have already provided (unless the data has already been de-identified or published)'...
                    '\n - I have been informed that the confidentiality of the information I provide will be protected and will only be used for purposes that I have agreed to. I understand that information about me will only be told to others\n   with my permission, except as required by law.'...
                    '\n - I understand that the results of this study may be published, and that publications will not contain my name or any identifiable information about me.'...
                    '\n \n I agree to take part in this research study:\n Please press the ''y'' key to agree or press the ''n'' key if you do not agree.'... 
                  ];
 
    RestrictKeysForKbCheck([KbName('y') KbName('n')]);
    DrawFormattedText(MainWindow, ConsentText,20, 'center', black,[],[],[],2);   
    Screen('Flip',MainWindow);
    KbWait([],2);
    [ keyIsDown, seconds, keyCode ] = KbCheck;
    consent =  KbName(keyCode); 
    
    if consent == 'n' 
        DrawFormattedText(MainWindow, 'Please let the experimenter know that you have not agreed to participate' ,'center', 'center', black,[],[],[],2);   
        Screen('Flip',MainWindow);
        RestrictKeysForKbCheck(KbName('F10'));
        KbWait([],2);
        sca; % close decline screen
    end
   
    afterConsent = ['Please let the experimenter know that you have consented to participating in the experiment.'];
    DrawFormattedText(MainWindow, afterConsent,'center', 'center', black,[],[],[],2);
    Screen('Flip',MainWindow);
    RestrictKeysForKbCheck(KbName('space'));
    KbWait([],2);
    sca;% close consent screen if opened
    
else
    % If session 2, consent already obtained and continues to hold
    consent = 'y';
    input('Press Enter to start calibration');
end 

%% RUN CALIBRATION
% Run calibration before ppt has to enter any details in case of sync
% problems 


if runET == 1
    CalibBug = [];
    while isempty(CalibBug) 
    clc;
    
    tobii = EyeTrackingOperations();
    found_eyetrackers = tobii.find_all_eyetrackers();
    my_eyetracker = found_eyetrackers(1);
    
    
    
    disp(['Address: ', my_eyetracker.Address])
    disp(['Model: ', my_eyetracker.Model])
    disp(['Name (It''s OK if this is empty): ', my_eyetracker.Name])
    disp(['Serial number: ', my_eyetracker.SerialNumber])
    
    
%     calib = 'a';
%     while ~strcmpi(calib, 'y')
%         calib = input('Type "y" and press Enter after calibration complete --->   ', 's');
%         if isempty(calib); calib = 'a'; end
%     end
    
    
%     
%     [MainWindow] = Screen(screenID, 'OpenWindow',white, [0, 0, screenWidth , screenHeight ]);
%     Screen('Preference', 'VisualDebugLevel', 3);
%     Screen('BlendFunction', MainWindow, 'GL_SRC_ALPHA', 'GL_ONE_MINUS_SRC_ALPHA');
%     
%     Screen('TextFont', MainWindow, 'Calibri');
%     
%     
  GenericCalibration; runET = 1;
    end
    
    clearvars('CalibBug')
end

