/////////////////////////////////////////////////////
///////// DEFINE ALL RELEVANT VARIABLES//////////////
/////////////////////////////////////////////////////
var n_repeats = 10;

var cue_images = [
'<p> </p><img src="images/Cue1.png"></img>',
'<p> </p><img src="images/Cue2.png"></img>',
'<p> </p><img src="images/Cue3.png"></img>',
'<p> </p><img src="images/Cue4.png"></img>'
];

//all stim to sample from 
var all_stim = [
"images/1_or0_c1.png",
"images/2_or0_c2.png", 
"images/3_or0_c3.png",
"images/4_or0_c4.png", 
"images/5_or90_c1.png",
"images/6_or90_c2.png",
"images/7_or90_c3.png", 
"images/8_or90_c4.png", 
"images/9_or45_c1.png", 
"images/10_or45_c2.png", 
"images/11_or45_c3.png", 
"images/12_or45_c4.png", 
"images/13_or135_c1.png", 
"images/14_or135_c2.png", 
"images/15_or135_c3.png", 
"images/16_or135_c4.png"
];

var out_color = [
'#77AADD', //c1: light blue 
'#44BB99', //c2: mint
'#EEDD88', //c3: light yellow
'#FFAABB' //c4: pink
];

var out_x_loc = [
50, // location 1
260, // location 2 
480, // location 3
695 // location 4
];

var out_x_ind = [0,1,2,3];

var out_y = 35; // y is always the same

// Valid combinations of stim for the experiment (from R code) 
var stim_comb = [{"n1":0,"n2":5,"n3":10,"n4":15,"c1":0,"c2":1,"c3":2,"c4":3},{"n1":0,"n2":5,"n3":11,"n4":14,"c1":0,"c2":1,"c3":3,"c4":2},{"n1":0,"n2":6,"n3":9,"n4":15,"c1":0,"c2":2,"c3":1,"c4":3},{"n1":0,"n2":6,"n3":11,"n4":13,"c1":0,"c2":2,"c3":3,"c4":1},{"n1":0,"n2":7,"n3":9,"n4":14,"c1":0,"c2":3,"c3":1,"c4":2},{"n1":0,"n2":7,"n3":10,"n4":13,"c1":0,"c2":3,"c3":2,"c4":1},{"n1":1,"n2":4,"n3":10,"n4":15,"c1":1,"c2":0,"c3":2,"c4":3},{"n1":1,"n2":4,"n3":11,"n4":14,"c1":1,"c2":0,"c3":3,"c4":2},{"n1":1,"n2":6,"n3":8,"n4":15,"c1":1,"c2":2,"c3":0,"c4":3},{"n1":1,"n2":6,"n3":11,"n4":12,"c1":1,"c2":2,"c3":3,"c4":0},{"n1":1,"n2":7,"n3":8,"n4":14,"c1":1,"c2":3,"c3":0,"c4":2},{"n1":1,"n2":7,"n3":10,"n4":12,"c1":1,"c2":3,"c3":2,"c4":0},{"n1":2,"n2":4,"n3":9,"n4":15,"c1":2,"c2":0,"c3":1,"c4":3},{"n1":2,"n2":4,"n3":11,"n4":13,"c1":2,"c2":0,"c3":3,"c4":1},{"n1":2,"n2":5,"n3":8,"n4":15,"c1":2,"c2":1,"c3":0,"c4":3},{"n1":2,"n2":5,"n3":11,"n4":12,"c1":2,"c2":1,"c3":3,"c4":0},{"n1":2,"n2":7,"n3":8,"n4":13,"c1":2,"c2":3,"c3":0,"c4":1},{"n1":2,"n2":7,"n3":9,"n4":12,"c1":2,"c2":3,"c3":1,"c4":0},{"n1":3,"n2":4,"n3":9,"n4":14,"c1":3,"c2":0,"c3":1,"c4":2},{"n1":3,"n2":4,"n3":10,"n4":13,"c1":3,"c2":0,"c3":2,"c4":1},{"n1":3,"n2":5,"n3":8,"n4":14,"c1":3,"c2":1,"c3":0,"c4":2},{"n1":3,"n2":5,"n3":10,"n4":12,"c1":3,"c2":1,"c3":2,"c4":0},{"n1":3,"n2":6,"n3":8,"n4":13,"c1":3,"c2":2,"c3":0,"c4":1},{"n1":3,"n2":6,"n3":9,"n4":12,"c1":3,"c2":2,"c3":1,"c4":0}];
////////////////END DEFINE VARIABLES//////////

//////////////////////////////////////////////////////
///////////START TRIAL CONSTRUTION PROCEDURE/////////
/////////////////////////////////////////////////////

// Construct per-participant stimulus values

// shuffle cue-stim contingencies
var cues = jsPsych.randomization.shuffleNoRepeats(jsPsych.randomization.repeat(cue_images,1));

// sample a valid combination of stim for experiment
var stim_ind = jsPsych.randomization.sampleWithoutReplacement(stim_comb,1)[0]

// stim stores image location of selected row of stim 
var stim = [all_stim[stim_ind.n1], all_stim[stim_ind.n2],all_stim[stim_ind.n3],all_stim[stim_ind.n4]];

// map right colors to sampled stim
var out_cue = [out_color[stim_ind.c1],out_color[stim_ind.c2],out_color[stim_ind.c3],out_color[stim_ind.c4]];

// define slots for outcomes to appear that can move x locations with randomization

var out_slot = ["slot0","slot1","slot2","slot3"]; 

// shuffle cues, out_cue and stim with same indices so locations are randomized per trial
var trial_shuffle = jsPsych.randomization.shuffleNoRepeats(jsPsych.randomization.repeat([0,1,2,3],1));

var cues_mat = [[cues[trial_shuffle[0]],cues[trial_shuffle[1]],cues[trial_shuffle[2]],cues[trial_shuffle[3]]]];
var stim_mat = [[stim[trial_shuffle[0]],stim[trial_shuffle[1]],stim[trial_shuffle[2]],stim[trial_shuffle[3]]]];
var out_cue_mat = [[out_cue[trial_shuffle[0]],out_cue[trial_shuffle[1]],out_cue[trial_shuffle[2]],out_cue[trial_shuffle[3]]]];
var out_slot_mat = [[out_slot[trial_shuffle[0]],out_slot[trial_shuffle[1]],out_slot[trial_shuffle[2]],out_slot[trial_shuffle[3]]]];

// construct a matrix relating slots to locations 

var slot_to_loc_mat = [trial_shuffle.slice()];
console.log(out_slot_mat[0]);
console.log(slot_to_loc_mat[0]);

// For loop for each shuffle of location 
for(var i = 1; i < 4 * n_repeats; i++){
	// shuffle indices
	var trial_shuffle = jsPsych.randomization.shuffleNoRepeats(jsPsych.randomization.repeat([0,1,2,3],1));

	// new row of each var for new indices
	stim_mat.push([stim[trial_shuffle[0]],stim[trial_shuffle[1]],stim[trial_shuffle[2]],stim[trial_shuffle[3]]]);
	cues_mat.push([cues[trial_shuffle[0]],cues[trial_shuffle[1]],cues[trial_shuffle[2]],cues[trial_shuffle[3]]]);
	out_cue_mat.push([out_cue[trial_shuffle[0]],out_cue[trial_shuffle[1]],out_cue[trial_shuffle[2]],out_cue[trial_shuffle[3]]]);
	out_slot_mat.push([out_slot[trial_shuffle[0]],out_slot[trial_shuffle[1]],out_slot[trial_shuffle[2]],out_slot[trial_shuffle[3]]]);
};



console.log(stim);
console.log(cues_mat[0]);
console.log(stim_mat[0]);
console.log(out_slot_mat[0]);
console.log(out_cue_mat[0]);
console.log(out_slot_mat[1]);
console.log(out_cue_mat[1]);
console.log(out_slot_mat[2]);
console.log(out_cue_mat[2]);
console.log(out_slot_mat[3]);
console.log(out_cue_mat[3]);
console.log(out_slot_mat[4]);
console.log(out_cue_mat[4]);

// generate order of correct responses (x locations), using no repeat to stop consecutive trials having the same answer 
// number in repeat determines length of experiment 
var out_x_seq = jsPsych.randomization.shuffleNoRepeats(jsPsych.randomization.repeat(out_x_ind,n_repeats)); // sequence of correct feebdack


// use correct answers to construct order of outcome cues 
// get last trial value 
var out_cue_seq = out_x_seq.slice(1); // slice out x array to drop first value; sequence of outcome colors

var last_outcome = out_cue_seq[out_cue_seq.length-1]; // get last outcome so it isn't repeated 

var copy_out_x_ind = out_x_ind.slice()

var drop_x_index = copy_out_x_ind.indexOf(last_outcome); // get index of last value for dropping

copy_out_x_ind.splice(drop_x_index, 1); // drop value of first outcome location from out_x_loc


var last_trial_samp = jsPsych.randomization.sampleWithoutReplacement(copy_out_x_ind,1)[0]

// add new last trial to outcome
out_cue_seq.push(last_trial_samp); 


// build trial sequence from params sampled above

// cue determined by out_x_seq
// outcome slot determined by out_x_seq
// stim loc determined by stim_mat (how related to sequence variables???)
// out_cue color determined by out_cue_seq 
// out_cue color needs to be related to slots 

// trial 0

var out_cue_slot_mat = out_slot_mat.slice(1)

out_cue_slot_mat.push([0,1,2,3]);

console.log(out_cue_slot_mat);

console.log(out_slot_mat[0][out_x_seq[0]]);
console.log(out_x_loc[out_slot_mat[0].indexOf(out_slot_mat[0][out_x_seq[0]])]);
console.log(out_cue_slot_mat[0][out_cue_seq[0]]);
//console.log(out_cue_mat[0][out_cue_slot_mat[0].indexOf(out_cue_slot_mat[0][out_cue_seq[0]])]);

// trial 1
console.log(out_slot_mat[1][out_x_seq[1]]);
console.log(out_x_loc[out_slot_mat[1].indexOf(out_slot_mat[1][out_x_seq[1]])]);
console.log(out_cue_slot_mat[1][out_cue_seq[1]]);


// trial 2
console.log(out_slot_mat[2][out_x_seq[2]]);
console.log(out_x_loc[out_slot_mat[2].indexOf(out_slot_mat[2][out_x_seq[2]])]);
console.log(out_cue_slot_mat[2][out_cue_seq[2]]);


// trial 3
console.log(out_slot_mat[3][out_x_seq[3]]);
console.log(out_x_loc[out_slot_mat[3].indexOf(out_slot_mat[3][out_x_seq[3]])]);
console.log(out_cue_slot_mat[3][out_cue_seq[3]]);


// trial 4
console.log(out_slot_mat[4][out_x_seq[4]]);
console.log(out_x_loc[out_slot_mat[4].indexOf(out_slot_mat[4][out_x_seq[4]])]);
console.log(out_cue_slot_mat[4][out_cue_seq[4]]);


// 

var trial_stimuli = [{cue: cues_mat[0][out_x_seq[0]], stim1: stim_mat[0][0], stim2: stim_mat[0][1] , stim3: stim_mat[0][2], stim4: stim_mat[0][3], out_cue: out_cue_mat[0][out_cue_seq[0]],out_x: out_x_loc[out_slot_mat[0].indexOf(out_slot_mat[0][out_x_seq[0]])] ,out_y: out_y , trial: 0}];


for(var i = trial_stimuli[0].trial + 1; i < out_x_seq.length; i++){
	//var next_trial = {cue: cues[out_x_seq[i]], stim1: stim[0], stim2: stim[1] , stim3: stim[2], stim4: stim[3], out_cue: out_cue[out_cue_seq[i]],out_x: out_x_loc[out_x_seq[i]] ,out_y: out_y , trial: i};
	var next_trial = {cue: cues_mat[i][out_x_seq[i]], stim1: stim_mat[i][0], stim2: stim_mat[i][1] , stim3: stim_mat[i][2], stim4: stim_mat[i][3], out_cue: out_cue_mat[i][out_cue_seq[i]],out_x: out_x_loc[out_slot_mat[i].indexOf(out_slot_mat[i][out_x_seq[i]])] ,out_y: out_y , trial: i};
	trial_stimuli.push(next_trial)
};

console.log(trial_stimuli);
console.log(out_x_seq);
console.log(out_cue_seq);