

//////////////////////////////////////////////////////
///////////START TRIAL CONSTRUTION PROCEDURE/////////
/////////////////////////////////////////////////////

// Construct per-participant stimulus values

function generate_trial_sequence(stim_comb,cue_images,all_stim,out_color, out_x_loc = [50,260,480,695], phase, n_repeats = 8,
out_x_ind = [0,1,2,3], out_y = 35){

// cue array is already shuffled in index


// sample a valid combination of stim for experiment
var stim_ind = jsPsych.randomization.sampleWithReplacement(stim_comb,1)

console.log(stim_ind);

console.log(all_stim[stim_ind[0].resp1])

var stim = [{name: all_stim[stim_ind[0].resp1], color: stim_ind[0].resp1, cue: cue_images[stim_ind[0].cue1]}, 
			{name: all_stim[stim_ind[0].resp2], color: stim_ind[0].resp2, cue: cue_images[stim_ind[0].cue2]},
			{name: all_stim[stim_ind[0].resp3], color: stim_ind[0].resp3, cue: cue_images[stim_ind[0].cue3]},
			{name: all_stim[stim_ind[0].resp4], color: stim_ind[0].resp4, cue: cue_images[stim_ind[0].cue4]}];

console.log(stim);

// map right colors to sampled stim
var out_cue = [out_color[stim_ind[0].resp1],out_color[stim_ind[0].resp2],out_color[stim_ind[0].resp3],out_color[stim_ind[0].resp4]];

// shuffle stim and outcome together
var loc_shuffle = jsPsych.randomization.shuffleNoRepeats([0,1,2,3]);
var stim = [[stim[loc_shuffle[0]], stim[loc_shuffle[1]], stim[loc_shuffle[2]], stim[loc_shuffle[3]]]];

for(var i = 1; i < 4 * n_repeats ; i++){
	var loc_shuffle = jsPsych.randomization.shuffleNoRepeats([0,1,2,3]);
	
	var next_stim = [{name: all_stim[stim_ind[0].resp1], color: stim_ind[0].resp1, cue: cue_images[stim_ind[0].cue1]}, 
			{name: all_stim[stim_ind[0].resp2], color: stim_ind[0].resp2, cue: cue_images[stim_ind[0].cue2]},
			{name: all_stim[stim_ind[0].resp3], color: stim_ind[0].resp3, cue: cue_images[stim_ind[0].cue3]},
			{name: all_stim[stim_ind[0].resp4], color: stim_ind[0].resp4, cue: cue_images[stim_ind[0].cue4]}];
			
	 stim.push([next_stim[loc_shuffle[0]], next_stim[loc_shuffle[1]], next_stim[loc_shuffle[2]], next_stim[loc_shuffle[3]]]);

};

console.log(stim)

// slice out_cue at first trial to line up colour cue for next trial
var out_cue = stim.slice(1); 

out_cue.push([{name: all_stim[stim_ind[0].resp1], color: stim_ind[0].resp1, cue: cue_images[stim_ind[0].cue1]}, 
			{name: all_stim[stim_ind[0].resp2], color: stim_ind[0].resp2, cue: cue_images[stim_ind[0].cue2]},
			{name: all_stim[stim_ind[0].resp3], color: stim_ind[0].resp3, cue: cue_images[stim_ind[0].cue3]},
			{name: all_stim[stim_ind[0].resp4], color: stim_ind[0].resp4, cue: cue_images[stim_ind[0].cue4]}]);





// generate order of correct responses (x locations), using no repeat to stop consecutive trials having the same answer 
// number in repeat determines length of experiment 
var out_x_seq = jsPsych.randomization.shuffleNoRepeats(jsPsych.randomization.repeat(out_x_ind,n_repeats)); // sequence of correct feebdack


// use correct answers to construct order of outcome cues 
// get last trial value 
var out_cue_seq = out_x_seq.slice(1); // slice out x array to drop first value; sequence of outcome colors

var last_outcome = out_cue_seq[out_cue_seq.length-1]; // get last outcome so it isn't repeated 

var copy_out_x_ind = out_x_ind.slice()

var drop_x_index = copy_out_x_ind.indexOf(last_outcome); // get index of last value for dropping

copy_out_x_ind.splice(drop_x_index, 1); // drop value of first outcome location from out_x_loc


var last_trial_samp = jsPsych.randomization.sampleWithoutReplacement(copy_out_x_ind,1)[0]

// add new last trial to outcome
out_cue_seq.push(last_trial_samp); 

console.log(out_x_seq);
console.log(out_cue_seq);
// build trial sequence from params sampled above

// cue determined by out_x_seq
// outcome slot determined by out_x_seq
// stim loc determined by stim_mat (how related to sequence variables???)
// out_cue color determined by out_cue_seq 
// out_cue color needs to be related to slots 

// trial 0


//trial_stimuli = [{cue: stim[0].find(el => el.or === out_x_seq[0]).cue, correct: stim[0].find(el => el.or === out_x_seq[0]).name, stim1: stim[0][0].name, stim2: stim[0][1].name , stim3: stim[0][2].name, stim4: stim[0][3].name, out_cue: out_color[out_cue[0].find(el => el.or === out_cue_seq[0]).color].hex,out_x: out_x_loc[stim[0].findIndex(el => el.or === out_x_seq[0])],out_y: out_y , trial: 0, phase: phase}];

console.log(stim[0][0].cue)
console.log(stim[0].find(el => el.color === out_x_seq[0]).cue)

var trial_stimuli = [{cue: stim[0].find(el => el.color === out_x_seq[0]).cue, correct: stim[0].find(el => el.color === out_x_seq[0]).name, stim1: stim[0][0].name, stim2: stim[0][1].name , stim3: stim[0][2].name, stim4: stim[0][3].name, out_cue: out_color[out_cue[0].find(el => el.color === out_cue_seq[0]).color].hex,out_x: out_x_loc[stim[0].findIndex(el => el.color === out_x_seq[0])],out_y: out_y , trial: 0, phase: phase}];

console.log(trial_stimuli);

for(var i = trial_stimuli[0].trial + 1; i < out_x_seq.length; i++){
	//var next_trial = {cue: cues[out_x_seq[i]], stim1: stim[0], stim2: stim[1] , stim3: stim[2], stim4: stim[3], out_cue: out_cue[out_cue_seq[i]],out_x: out_x_loc[out_x_seq[i]] ,out_y: out_y , trial: i};
	var next_trial = {cue: stim[i].find(el => el.color === out_x_seq[i]).cue, correct: stim[i].find(el => el.color === out_x_seq[i]).name, stim1: stim[i][0].name, stim2: stim[i][1].name , stim3: stim[i][2].name, stim4: stim[i][3].name, out_cue: out_color[out_cue[i].find(el => el.color === out_cue_seq[i]).color].hex,out_x: out_x_loc[stim[i].findIndex(el => el.color === out_x_seq[i])],out_y: out_y , trial: i, phase: phase};
	trial_stimuli.push(next_trial)
};




return(trial_stimuli);

};